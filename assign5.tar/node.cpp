#include <iostream>
#include <string>
#include "node.h"

using namespace std;

/*********************************************************************
** Function: Node constructor
** Description: Creates a new Node with default values
** Parameters: none
** Pre-Conditions: is no Node
** Post-Conditions: exists new Node
*********************************************************************/
Node::Node()
{
	val = 0;
	next = NULL;
}

/*********************************************************************
** Function: Node destructor
** Description: called when Npde goes out of scope
** Parameters: none
** Pre-Conditions: exists Node
** Post-Conditions: Node is gone
*********************************************************************/
Node::~Node()
{}