Name: Mitchell Stewart
ONID: 933-291-448
Class: CS 162, section 20
Assignment 5, due 6/7/2020

Description: 

Hello! This is program is a tester for something called a linked list. A linked list is a list of elements, in this case integers, that are linked together by a pathway that travels from the first element to the last. This program will test some functionalities of a linked list, including printing it out, sorting it in ascending/descending order, counting the number of prime numbers in it, and more. What is expected to show up will br printed, as well as what my program actually prints (so that the two can be compared). For some of the tests, whether my program "passed" or not will be printed.

Instructions:

1) compile the program with 

g++ test_linked_list.cpp linked_list.cpp node.cpp -o assign5

or

make

2) run the program with

./assign5

3) To start off, the results of the first 2 tests will be printed. If the get_length function works correctly, the linked list is successfully created, and the push_front function works, then you can press enter to go to the next tests. If at any point you would like to quit, control c will do it.

Next to be tested is the push_back function, if the expected list matches the actual list and the lengths match up, pressing enter will move on to the next test

Insert will now be testing. Again, if the expected and actual lists are the same and the lengths are the same, you can move on to the next test using enter

The next test will see if sorting works when done in ascending order, press enter if the information matches up.

The test after sorting in ascending order is sorting in descending order. If it works, press enter ot advance.

The last two tests are count_prime and clear. If the actual number of prime numbers is correct, and the linked list is deleted correctly, "passed" will be printed. This concludes the program.

4) Limitations: 
-no user input, which may make it more interesting
-limited to the functions that are tested
-the success of some of the later tests can be based on the success of previous tests

5) No extra credit was done

6) Complexity Analysis:

sort_ascending():

For this function, I used merge sort. This is a divide and conquer algorithm. Essentially, you split the starting linked list into smaller linked lists until everything is in its own linked list. After this, you begin combining the individual linked lists and putting them in order, until eventually you have your original linked list in the correct order. For example, 1 4 2 9 6 3 becomes 1 | 4 | 2 | 9 | 6 | 3 which becomes 1 | 4 2 | 9 | 3 6 which becomes 1 2 4 | 3 6 9 which then finally turns into 1 2 3 4 6 9. 

The complexity of this algorithm is O(nlogn). The merge step will have to execute for n time. Because of the recursion in merge sort, the splitting into 2 subarrays happsn logn times, thus the complexity is nlogn.

sort_descending():

In this function, I also used merge sort. The only thing that was different about this function was that elements were compared using the opposite sign. As a result, the overall sorting worked the same.

Nothing was changed that would change the time complexity, so it is still O(nlogn).

count_prime():

My count prime function looped through the linked list, checking if any numbers in it were prime. It did this using the helper function "is_prime" which checked if a number was prime by seeing if any number less than it could be divided by the original number to = 0. If not, then the function returned false. 

Both the original function and the function contained loops which would take time O(n). Because one of these loops was contained in the other, the time complexity for count_prime is O(n^2).


