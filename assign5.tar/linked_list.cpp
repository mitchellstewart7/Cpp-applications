#include <iostream>
#include <cstdlib>
#include <string>
#include "linked_list.h"

using namespace std;

/*********************************************************************
** Function: Linked_List
** Description: creates linked list
** Parameters: none
** Pre-Conditions: no linked list
** Post-Conditions: created linked list
*********************************************************************/
Linked_List::Linked_List()
{
	this->length = 0;
	this->head = NULL;
	this->current = head;
}

/*********************************************************************
** Function: ~Linked_List
** Description: deletes linked list
** Parameters: none
** Pre-Conditions: linked list exists
** Post-Conditions: no linked list
*********************************************************************/
Linked_List::~Linked_List()
{}

/*********************************************************************
** Function: get_length
** Description: returns link list length
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: returned value
*********************************************************************/
int Linked_List::get_length()
{
	return this->length;
}

/*********************************************************************
** Function: print
** Description: prints out linked list values
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed out values
*********************************************************************/
void Linked_List::print()
{
	current = head;
	while (current != NULL)
	{
		cout << current->val << " ";
		current = current->next;
	}
	cout << endl;
}

/*********************************************************************
** Function: clear
** Description: deletes dynamic memory and sets length to zero
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: free memory
*********************************************************************/
void Linked_List::clear()
{
	current = head;
	Node * next;
	while (current != NULL)
	{
		next = current->next;
		delete current;
		current = next;
	}
	this->length = 0;
}

/*********************************************************************
** Function: push_front
** Description: puts value in front of linked list
** Parameters: int value
** Pre-Conditions: none
** Post-Conditions: value at fron of linked list
*********************************************************************/
void Linked_List::push_front(int value)
{
	this->length++;
	Node * n = new Node;
	n->next = head;
	head = n;
	head->val = value;
}

/*********************************************************************
** Function: push_back
** Description: puts value at back of linked list
** Parameters: int value
** Pre-Conditions: none
** Post-Conditions: new linked list with value at back
*********************************************************************/
void Linked_List::push_back(int value)
{
	Node * n = new Node;
	n->val = value;
	current = head;
	while (current->next != NULL)
	{
		current = current->next;
	}
	current->next = n;
	length++;
}

/*********************************************************************
** Function: insert
** Description: puts value at given index
** Parameters: int value and unsigned int index
** Pre-Conditions: none
** Post-Conditions: new link list with value in correct index
*********************************************************************/
//over 15 lines due to multiple if statements which were necessary for the function to work as desired
void Linked_List::insert(int val, unsigned int index)
{
	current = head;
	if (index == 0)
	{
		this->push_front(val);
	}
	else
	{
		if (index < this->length)
		{
			for (int i = 0; i < index - 1; ++i)
			{
				current = current->next;
			}
			Node * n = new Node;
			n->val = val;
			n->next = current->next;
			current->next = n;
			this->length++;
		}
		else if (index == this->length)
		{
			this->push_back(val);
		}
		else
		{
			cout << "Number not within linked list length" << endl;
		}
	}
}

/*********************************************************************
** Function: sort_ascending
** Description: puts link list in ascending order
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: ordered link list
*********************************************************************/
void Linked_List::sort_ascending()
{
	merge_sort(&head, 0);
}

/*********************************************************************
** Function: merge_sort
** Description: runs the merge sort
** Parameters: Node double pointer, and an integer
** Pre-Conditions: none
** Post-Conditions: ordered link list
*********************************************************************/
void Linked_List::merge_sort(Node ** head_node, int mode)
{
	Node * head2 = *head_node;
	Node * a;
	Node * b;
	if ((head2 == NULL) || (head2->next == NULL))
	{
		return;
	}
	split(head2, &a, &b);
	merge_sort(&a, mode);
	merge_sort(&b, mode);
	*head_node = merge(a, b, mode);
}

/*********************************************************************
** Function: merge
** Description: merges two halves together in specified order
** Parameters: two Node pointers, and an integer
** Pre-Conditions: none
** Post-Conditions: combined halves
*********************************************************************/
//over 15 lines due to multiple if statements which as necessary
Node * Linked_List::merge(Node * first, Node * second, int mode)
{
	Node * final = NULL;
	if (first == NULL)
	{
		return second;
	}
	else if (second == NULL)
	{
		return first;
	}
	if (mode == 0)
	{
		if (first->val <= second->val)
		{
			final = first;
			final->next = merge(first->next, second, mode);
		}
		else 
		{
			final = second;
			final->next = merge(first, second->next, mode);
		}
	}
	else
	{
		if (first->val >= second->val)
		{
			final = first;
			final->next = merge(first->next, second, mode);
		}
		else 
			{
			final = second;
			final->next = merge(first, second->next, mode);
		}
	}
	return final;
}

/*********************************************************************
** Function: split
** Description: splits linked list into halves
** Parameters: two Node double pointers, and a Node pointer
** Pre-Conditions: none
** Post-Conditions: two pieces exist
*********************************************************************/
void Linked_List::split(Node * head_node, Node ** first, Node ** second)
{
	Node * fast;
	Node * slow;
	slow = head_node;
	fast = head_node->next;
	while (fast != NULL)
	{
		fast = fast->next;
		if (fast != NULL)
		{
			slow = slow->next;
			fast = fast->next;
		}
	}
	*first = head_node;
	*second = slow->next;
	slow->next = NULL;
}

/*********************************************************************
** Function: sort_descending
** Description: puts link list in descending order
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: ordered link list
*********************************************************************/
void Linked_List::sort_descending()
{
	merge_sort(&head, 1);
}

/*********************************************************************
** Function: count_prime
** Description: returns number of prime numbers in linked list
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: integer returned
*********************************************************************/
unsigned int Linked_List::count_prime()
{
	unsigned int count = 0;
	current = head;
	while (current->next != NULL)
	{
		if (this->is_prime(current->val))
		{
			count++;
		}
		current = current->next;
	}
	return count;
}

/*********************************************************************
** Function: is_prime
** Description: checks if given number is prime
** Parameters: integer
** Pre-Conditions: none
** Post-Conditions: true is number is prime, false otherwise
*********************************************************************/
//over 15 lines because of multiple if statements, which are necessary because of variety of cases
bool Linked_List::is_prime(int number)
{
	if (number < 0)
	{
		for (int i = number + 1; i < -1; ++i)
		{
			if (number % i == 0)
			{
				return false;
			}
		}
	}
	else if (number == 2)
	{
		return true;
	}
	else if (number == 0 || number == 1)
	{
		return false;
	}
	else
	{
		for (int i = 2; i < number; ++i)
		{
			if (number % i == 0)
			{
				return false;
			}		
		}
	}
	return true;
}