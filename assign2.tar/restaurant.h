#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <string>
#include <fstream>
#include <iostream>
#include "menu.h"
#include "emp_hours.h"
#include "orders.h"

using namespace std;

class Restaurant {
  private:
  	//member variables
    Menu menu;
    employee* employees;
    hours* week;
    order * orders;
    string name;
    string phone;
    string address;
    int num_orders;
  public:

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Declares a restaurant object
    ** Input: none
    ** Output: new restaurant
    ******************************************************/
    Restaurant();
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Declares a restaurant object
    ** Input: All the characteristics of the restaurant
    ** Output: new restaurant
    ******************************************************/
    Restaurant(Menu menu, employee * employees, hours * week, order * orders, string name, string phone, string address, int num_orders);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: deletes restaurant object when it goes out of scope
    ** Input: none
    ** Output: deleted restaurant
    ******************************************************/
    ~Restaurant();
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Initializes restaurant object to equal paramter
    ** Input: restaurant object
    ** Output: new restaurant deep copied
    ******************************************************/
    Restaurant(const Restaurant & restaurant);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: sets values of restaurant equal to parameter with deep copy
    ** Input: none
    ** Output: Address of a restaurant
    ******************************************************/
    Restaurant & operator=(const Restaurant & restaurant);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets number of employees
    ** Input: none
    ** Output: value
    ******************************************************/
    int get_num_employees();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets number of days in the week
    ** Input: none
    ** Output: value
    ******************************************************/
    int get_num_hours();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets name
    ** Input: none
    ** Output: value
    ******************************************************/
    string get_name();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets number of pizzas
    ** Input: none
    ** Output: value
    ******************************************************/
    int get_num_pizzas();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets number of orders
    ** Input: none
    ** Output: value
    ******************************************************/
    int get_num_orders();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: sets number of pizzas
    ** Input: desired value
    ** Output: void, but changed value
    ******************************************************/
    void set_num_pizzas(int num);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: sets number of orders
    ** Input: desired value
    ** Output: void, but changed value
    ******************************************************/
    void set_num_orders(int num);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: loads all necessary data into restaurant
    ** Input: none
    ** Output: populated restaurant from text files
    ******************************************************/
	void load_data(); 
    
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: loads all necessary data into menu
    ** Input: none
    ** Output: populated restaurant from text files
    ******************************************************/
    void load_menu();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: loads all necessary data into restaurant info
    ** Input: none
    ** Output: populated restaurant from text files
    ******************************************************/
    void load_restaurant_info();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: loads all necessary data into employees
    ** Input: none
    ** Output: populated restaurant from text files
    ******************************************************/
    void load_employees();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: loads all necessary data into orders
    ** Input: none
    ** Output: populated restaurant from text files
    ******************************************************/
    void load_orders();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: logs employee in
    ** Input: none
    ** Output: logged in employee
    ******************************************************/
    int welcome();
    bool login(int id, string password);
    void base_login();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: outputs what is in each part
    ** Input: none
    ** Output: text file output
    ******************************************************/
    void view_menu();
    void view_hours();
    void view_address();
    void view_phone();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: search by different characterstics
    ** Input: none
    ** Output: print out sorted menu, let user order
    ******************************************************/
    void search_menu_by_price();
    void search_by_ingredients();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: print options
    ** Input: none
    ** Output: printed options
    ******************************************************/
    int view_employee_options();
    int view_customer_options();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: runs if pick customer or employee
    ** Input: none
    ** Output: runs function
    ******************************************************/
    void run_customer();
    void run_employee();
    
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: places orders
    ** Input: none
    ** Output: order placed in orders.txt
    ******************************************************/
    void place_order(Pizza* selection, int selection_size, string* num_ordered, Menu & m);
    int number_pizzas_ordered();
    void add_order(order o);
    
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: allows user to change hours store is open
    ** Input: none
    ** Output: none
    ******************************************************/
    void change_hours();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: write different parts to file
    ** Input: none
    ** Output: value
    ******************************************************/
    void write_hours();
    void write_menu();
    void write_orders();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: takes item off menu
    ** Input: none
    ** Output: none
    ******************************************************/
    void remove_from_menu();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: view list of orders
    ** Input: none
    ** Output: none
    ******************************************************/
    void view_orders();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: takes order off of order list
    ** Input: none
    ** Output: none
    ******************************************************/
    void remove_orders();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: creates new order
    ** Input: none
    ** Output: order
    ******************************************************/
    order create_new_order(string items);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gives number of order to remove
    ** Input: none
    ** Output: integer number
    ******************************************************/
    int order_removal_num();
};

#endif
