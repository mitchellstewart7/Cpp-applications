#include <iostream>
#include <fstream>
#include <string>
#include "pizza.h"

using namespace std;

//default constructor

Pizza::Pizza()
{
	this->name = "pizza";
	this->small_cost = 0;
	this->medium_cost = 0;
	this->large_cost = 0;
	this->num_ingredients = 0;
	this->ingredients = NULL;
}

//non-default constructor
Pizza::Pizza(string name, int small_cost, int medium_cost, int large_cost, int num_ingredients, string * ingredients)
{
	this->name = name;
	this->small_cost = small_cost;
	this->medium_cost = medium_cost;
	this->large_cost = large_cost;
	this->num_ingredients = num_ingredients;
	this->ingredients = new string[num_ingredients];
}

//destructor
Pizza::~Pizza()
{
	if (this->ingredients != NULL)
	{
		delete [] this->ingredients;
		this->ingredients = NULL;
	}
}

//copy constructor
Pizza::Pizza(const Pizza & pizza)
{
	this->name = pizza.name;
	this->small_cost = pizza.small_cost;
	this->medium_cost = pizza.medium_cost;
	this->large_cost = pizza.large_cost;
	this->num_ingredients = pizza.num_ingredients;
	this->ingredients = new string[pizza.num_ingredients];
	for (int i = 0; i < pizza.num_ingredients; ++i)
	{
		this->ingredients[i] = pizza.ingredients[i];
	}
}

//assignment operator overload
//over 15 lines because of variable initialization
Pizza & Pizza::operator=(const Pizza & pizza)
{
	if (this != &pizza)
	{
		if (this->ingredients != NULL)
		{
			delete [] this->ingredients;
			this->ingredients = NULL;
		}
		this->name = pizza.name;
		this->small_cost = pizza.small_cost;
		this->medium_cost = pizza.medium_cost;
		this->large_cost = pizza.large_cost;
		this->num_ingredients = pizza.num_ingredients;
		this->ingredients = new string[pizza.num_ingredients];
		for (int i = 0; i < pizza.num_ingredients; i++)
		{
			this->ingredients[i] = pizza.ingredients[i];
		}
	}
	return *this;
}

//mutators

void Pizza::set_name(string name)
{
	this->name = name;
}

void Pizza::set_num_ingredients(int num)
{
	this->num_ingredients = num;
}

void Pizza::set_small_cost(int small_cost)
{
	this->small_cost = small_cost;
}

void Pizza::set_medium_cost(int medium_cost)
{
	this->medium_cost = medium_cost;
}

void Pizza::set_large_cost(int large_cost)
{
	this->large_cost = large_cost;
}

void Pizza::populate_pizza(ifstream & fin)
{
	fin >> this->name >> this->small_cost >> this->medium_cost >> this->large_cost >> this->num_ingredients;
	this->ingredients = new string[this->num_ingredients];
	for (int i = 0; i < this->num_ingredients; i++)
	{
		fin >> this->ingredients[i];
	}
}

void Pizza::set_ingredients()
{
	this->ingredients = new string[this->get_num_ingredients()];
	for (int i = 0; i < this->get_num_ingredients(); ++i)
	{
		string str;
		cout << "What ingredient would you like to add?" << endl;
		cin >> str;
		this->ingredients[i] = str;
	}
}

//accesors

string Pizza::get_name() const
{
	return this->name;
}

int Pizza::get_num_ingredients() const
{
	return this->num_ingredients;
}

int Pizza::get_small_cost() const
{
	return this->small_cost;
}

int Pizza::get_medium_cost() const
{
	return this->medium_cost;
}

int Pizza::get_large_cost() const
{
	return this->large_cost;
}

string * Pizza::get_ingredients() const
{
	return this->ingredients;
}
