#include <iostream>
#include <fstream>
#include <string>
#include "menu.h"
#include "pizza.h"

using namespace std;

//default constructor
Menu::Menu()
{
	this->num_pizzas = 0;
	this->pizzas = NULL;
}

//non-default constructor
Menu::Menu(int num_pizzas, Pizza * pizzas)
{
	this->num_pizzas = num_pizzas;
	this->pizzas = pizzas;
}

//destructor
Menu::~Menu()
{
	if (this->pizzas != NULL)
	{
		delete [] this->pizzas;
		this->pizzas = NULL;
	}
}

//copy constructor
Menu::Menu(const Menu & menu)
{
	this->num_pizzas = menu.num_pizzas;
	this->pizzas = new Pizza[this->num_pizzas];
	for (int i = 0; i < this->num_pizzas; ++i)
	{
		this->pizzas[i] = menu.pizzas[i];
	}
}

//assignment operator overload
Menu & Menu::operator=(const Menu & menu)
{
	if (this != &menu)
	{
		this->num_pizzas = menu.num_pizzas;
		if (this->pizzas != NULL)
		{
			delete [] this->pizzas;
		}
		this->pizzas = new Pizza[this->num_pizzas];
		for (int i = 0; i < this->num_pizzas; ++i)
		{
			this->pizzas[i] = menu.pizzas[i];
		}
	}
	return *this;
}

//getters
int Menu::get_num_pizzas()
{
	return this->num_pizzas;
}
Pizza * Menu::get_pizzas()
{
	return this->pizzas;
}

//setters
void Menu::set_num_pizzas(int num)
{
	this->num_pizzas = num;
}
void Menu::create_pizzas(int num_pizzas)
{
	this->pizzas = new Pizza[num_pizzas];
}

//over 15 lines because it has to handle user input
Pizza Menu::create_new_pizza()
{
	string str;
	int num;
	Pizza p;
	cout << "What would you like to name the new pizza?" << endl;
	cin >> str;
	p.set_name(str);
	cout << "What would you like the small cost to be (in dollars)?" << endl;
	cin >> num;
	p.set_small_cost(num);
	cout << "What would you like the medium cost to be (in dollars)?" << endl;
	cin >> num;
	p.set_medium_cost(num);
	cout << "What would you like the large cost to be (in dollars)?" << endl;
	cin >> num;
	p.set_large_cost(num);
	cout << "How many ingredients would you like there to be?" << endl;
	cin >> num;
	p.set_num_ingredients(num);
	p.set_ingredients();
	return p;
}

void Menu::add_to_menu(Pizza p)
{
	Pizza * p_temp = new Pizza[this->num_pizzas + 1];
	for (int i = 0; i < this->num_pizzas; ++i)
	{
		p_temp[i] = this->pizzas[i];
	}
	p_temp[this->num_pizzas] = p;
	if (this->pizzas != NULL)
	{
		delete [] this->pizzas;
	}
	this->pizzas = p_temp;
	this->num_pizzas++;
}

void Menu::remove_from_menu(string name)
{
	int index = -1;
	for (int i = 0; i < this->num_pizzas; ++i)
	{
		if (this->pizzas[i].get_name() == name)
		{
			index = i;
		}
	}
	if (index == -1)
	{
		cout << "No pizza matches that name" << endl;
		return;
	}
	for (int i = index; i < this->num_pizzas - 1; ++i)
	{
		this->pizzas[i] = this->pizzas[i + 1];
	}
	this->num_pizzas--;
}

void Menu::pick_ingredients(string * ingredients, int num)
{
	for (int i = 0; i < num; ++i)
	{
		string ingredient;
		cout << "Name one ingredient would you like to include/exclude?" << endl;
		cin >> ingredient;
		ingredients[i] = ingredient;
	}
}

//over 15 lines because of triple for loop
Menu Menu::search_pizza_by_ingredients_to_exclude()
{
	Menu m = *this;
	int num;
	cout << "How many ingredients would you like to exclude?" << endl;
	cin >> num;
	string * ingredients = new string[num];
	this->pick_ingredients(ingredients, num);
	for (int i = 0; i < this->num_pizzas; ++i)
	{
		for (int j = 0; j < this->pizzas[i].get_num_ingredients(); ++j)
		{
			for (int k = 0; k < num; ++k)
			{
				if (this->pizzas[i].get_ingredients()[j] == ingredients[k])
				{
					m.remove_from_menu(this->pizzas[i].get_name());
				}
			}
		}
	}
	delete [] ingredients;
	return m;
}

//over 15 lines because of triple for loop
Menu Menu::search_pizza_by_ingredients_to_include()
{
	Menu m = *this;
	int num;
	cout << "How many ingredients would you like to include?" << endl;
	cin >> num;
	string * ingredients = new string[num];
	this->pick_ingredients(ingredients, num);
	for (int i = 0; i < this->num_pizzas; ++i)
	{
		int total = 0;
		for (int j = 0; j < this->pizzas[i].get_num_ingredients(); ++j)
		{
			for (int k = 0; k < num; ++k)
			{
				if (this->pizzas[i].get_ingredients()[j] != ingredients[k])
				{
					total++;
				}
			}
		}
		if (total == (this->pizzas[i].get_num_ingredients()) * num)
		{
			m.remove_from_menu(this->pizzas[i].get_name());
		}
	}
	delete [] ingredients;
	return m;
}

Menu Menu::search_pizza_by_cost(int upper_bound)
{
	Menu m = *this;
	for (int i = 0; i < m.get_num_pizzas(); ++i)
	{
		if (m.pizzas[i].get_small_cost() > upper_bound)
		{
			m.pizzas[i].set_small_cost(-1);
		}
		if (m.pizzas[i].get_medium_cost() > upper_bound)
		{
			m.pizzas[i].set_medium_cost(-1);
		}
		if (m.pizzas[i].get_large_cost() > upper_bound)
		{
			m.pizzas[i].set_large_cost(-1);
		}
	}
	return m;
}

//over 15 lines because of if statements
void Menu::print_search_menu()
{
	for (int i = 0; i < this->get_num_pizzas(); i++)
	{
		cout << this->get_pizzas()[i].get_name() << " ";
		if (this->get_pizzas()[i].get_small_cost() == -1)
		{
			cout << "N/A";
		}  
		else 
		{
			cout << this->get_pizzas()[i].get_small_cost();
		}
		if (this->get_pizzas()[i].get_medium_cost() == -1)
		{
			cout << " N/A";
		}  
		else 
		{
			cout << " " << this->get_pizzas()[i].get_medium_cost();
		}
		if (this->get_pizzas()[i].get_large_cost() == -1)
		{
			cout << " N/A";
		}  
		else 
		{
			cout << " " << this->get_pizzas()[i].get_large_cost();
		}
		cout << " " << this->get_pizzas()[i].get_num_ingredients();
		for (int j = 0; j < this->get_pizzas()[i].get_num_ingredients(); ++j)
		{
			cout << " " << this->get_pizzas()[i].get_ingredients()[j];
		}
		cout << endl;
	}
}