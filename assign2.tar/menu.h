#ifndef MENU_H
#define MENU_H 

#include <string>
#include <fstream>
#include "pizza.h"

using namespace std;

class Menu {
  private:
    //member variables
    int num_pizzas;
    Pizza* pizzas;
  public:

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Declares a menu object
    ** Input: none
    ** Output: none
    ******************************************************/
    Menu();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Declares a menu object of specified parameters
    ** Input: none
    ** Output: none
    ******************************************************/
    Menu(int num_pizzas, Pizza * pizzas);
    
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Initializes menu with values of parameter
    ** Input: Address of menu
    ** Output: none
    ******************************************************/
    Menu(const Menu & menu);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Initializes a menu object
    ** Input: Address of menu
    ** Output: Address of menu
    ******************************************************/
    Menu & operator=(const Menu & menu);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Deletes menu object when leaves scope
    ** Input: none
    ** Output: none
    ******************************************************/
    ~Menu();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets value
    ** Input: none
    ** Output: value
    ******************************************************/
    int get_num_pizzas();
    Pizza * get_pizzas();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Sets value
    ** Input: value
    ** Output: none
    ******************************************************/
    void set_num_pizzas(int num);
    void create_pizzas(int num_pizzas);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: searches for pizza by cost
    ** Input: integer
    ** Output: menu
    ******************************************************/
    Menu search_pizza_by_cost(int upper_bound);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: lets user select their ingredients
    ** Input: string array and integer
    ** Output: none
    ******************************************************/
    void pick_ingredients(string * ingredients, int num_ingredients);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: searches through menu by ingredients to include or exclude
    ** Input: none
    ** Output: menu object
    ******************************************************/
    Menu search_pizza_by_ingredients_to_include();
    Menu search_pizza_by_ingredients_to_exclude();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: creates new pizza
    ** Input: none
    ** Output: pizza object
    ******************************************************/
    Pizza create_new_pizza();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: adds pizza to the menu
    ** Input: Pizza object
    ** Output: none
    ******************************************************/
    void add_to_menu(Pizza p);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: removes pizza from menu by name
    ** Input: string name
    ** Output: none
    ******************************************************/
    void remove_from_menu(string name);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: prints menu after a search
    ** Input: none
    ** Output: none
    ******************************************************/
    void print_search_menu();
};

#endif
