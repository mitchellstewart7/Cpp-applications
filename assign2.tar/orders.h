#ifndef ORDERS_H
#define ORDERS_H

#include <iostream>
#include <string>

using namespace std;

struct order 
{
	int number;
	string name;
	string card_number;
	string phone;
	string items;
};

#endif