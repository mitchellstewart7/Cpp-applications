#ifndef PIZZA_H
#define PIZZA_H

#include <string>
#include <fstream>

using namespace std;

class Pizza {
  private:
    //member variables
    string name;
    int small_cost;
    int medium_cost;
    int large_cost;
    int num_ingredients;
    string* ingredients;
  public:


    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Declares a pizza object
    ** Input: none
    ** Output: none
    ******************************************************/
    Pizza();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Declares a pizza object with given characteristics
    ** Input: desired characteristics
    ** Output: none
    ******************************************************/
    Pizza(string name, int small_cost, int medium_cost, int large_cost, int num_ingredients, string * ingredients);
    
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: destructor when it goes out of scope
    ** Input: none
    ** Output: none
    ******************************************************/
    ~Pizza();

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Initiates a menu object
    ** Input: pizza reference
    ** Output: none
    ******************************************************/
    Pizza(const Pizza & pizza);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: Initiates a menu object
    ** Input: pizza reference
    ** Output: pizza reference
    ******************************************************/
    Pizza & operator=(const Pizza & pizza);

    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: set different values
    ** Input: value
    ** Output: none
    ******************************************************/
    void set_name(string name);

    void set_num_ingredients(int num);

    void set_small_cost(int small_cost);

    void set_medium_cost(int medium_cost);

    void set_large_cost(int large_cost);

    void populate_pizza(ifstream & fin);

    void set_ingredients();
    
    /******************************************************
    ** Program: restaurant.h
    ** Author: Mitchell Stewart
    ** Date: 04/26/2020
    ** Description: gets different values
    ** Input: none
    ** Output: value
    ******************************************************/
    string get_name() const;

	int get_num_ingredients() const;

    int get_small_cost() const;

    int get_medium_cost() const;

    int get_large_cost() const;

    string * get_ingredients() const;

};

#endif
