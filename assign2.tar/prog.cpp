#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "restaurant.h"

using namespace std;

int main()
{
	Restaurant r1;
	r1.load_data();
	r1.base_login();
	
	return 0;
	
}
