#include <string>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include "menu.h"
#include "emp_hours.h"
#include "restaurant.h"
#include "orders.h"

using namespace std;

//default constructor
Restaurant::Restaurant()
{
	Menu menu;
	employee * employees = NULL;
	hours * week = NULL;
	order * orders = NULL;
	string name = "default";
	string phone = "9999999999";
	string address = "default";
	int num_orders;
}

//non-default constructor
Restaurant::Restaurant(Menu menu, employee * employees, hours * week, order * orders, string name, string phone, string address, int num_orders)
{
	this->menu = menu;
	this->employees = employees;
	this->week = week;
	this->orders = orders;
	this->name = name;
	this->phone = phone;
	this->address = address;
	this->num_orders = num_orders;
}

//getters
int Restaurant::get_num_employees()
{
	int num;
	ifstream fin;
	fin.open("employee.txt");
	fin >> num;
	fin.close();
	return num;
}
string Restaurant::get_name()
{
	return this->name;
}
int Restaurant::get_num_hours()
{
	int days = 7; //always seven days in a week
	return days;
}

int Restaurant::get_num_pizzas()
{
	int num;
	ifstream fin;
	fin.open("menu.txt");
	fin >> num;
	fin.close();
	return num;
}

int Restaurant::get_num_orders()
{
	int num;
	ifstream fin;
	fin.open("orders.txt");
	fin >> num;
	fin.close();
	return num;
}

//setters
void Restaurant::set_num_pizzas(int num)
{
	ofstream fout;
	fout.open("menu.txt", ios::trunc);
	fout << num;
	fout.close();
}

void Restaurant::set_num_orders(int num)
{
	ofstream fout;
	fout.open("orders.txt", ios::trunc);
	fout << num;
	fout.close();
}

//destructor
Restaurant::~Restaurant()
{
	if (this->employees != NULL)
	{
		delete [] this->employees;
		this->employees = NULL;
	}
	if (this->week != NULL)
	{
		delete [] this->week;
		this->week = NULL;
	}
	if (this->orders != NULL)
	{
		delete [] this->orders;
		this->orders = NULL;
	}
}

//copy constructor
//over 15 lines because of for loop and three arrays to loop through
Restaurant::Restaurant(const Restaurant & restaurant)
{
	this->menu = restaurant.menu;
	this->name = restaurant.name;
	this->phone = restaurant.phone;
	this->address = restaurant.address;
	this->num_orders = restaurant.num_orders;
	this->employees = new employee[this->get_num_employees()];
	for (int i = 0; i < this->get_num_employees(); ++i)
	{
		this->employees[i] = restaurant.employees[i];
	}
	this->week = new hours[this->get_num_hours()];
	for (int i = 0; i < this->get_num_hours(); ++i)
	{
		this->week[i] = restaurant.week[i];
	}
	this->orders = new order[this->get_num_orders()];
	for (int i = 0; i < this->get_num_orders(); ++i)
	{
		this->orders[i] = restaurant.orders[i];
	}
}

//assignment operator overload
//over 15 lines because of for loops and three arrays to loop through
Restaurant & Restaurant::operator=(const Restaurant & restaurant)
{
	if (this != &restaurant)
	{
		this->menu = restaurant.menu;
		this->name = restaurant.name;
		this->phone = restaurant.phone;
		this->address = restaurant.address;
		this->num_orders = restaurant.num_orders;
		this->employees = new employee[this->get_num_employees()];
		for (int i = 0; i < this->get_num_employees(); i++)
		{
			this->employees[i] = restaurant.employees[i];
		}
		this->week = new hours[this->get_num_hours()];
		for (int i = 0; i < this->get_num_hours(); i++)
		{
			this->week[i] = restaurant.week[i];
		}
		this->orders = new order[this->get_num_orders()];
		for (int i = 0; i < this->get_num_orders(); ++i)
		{
			this->orders[i] = restaurant.orders[i];
		}
	}
	return *this;
}

void Restaurant::load_data()
{
	//load everything individually
	this->load_menu();
	this->load_employees();
	this->load_restaurant_info();
	this->load_orders();
}

void Restaurant::load_menu()
{
	ifstream fin;
	fin.open("menu.txt");
	if (!fin.is_open())
	{
		cout << "Could not open file" << endl;
	}
	int num_pizzas;
	fin >> num_pizzas;
	this->menu.set_num_pizzas(num_pizzas);
	this->menu.create_pizzas(this->menu.get_num_pizzas());
	for (int i = 0; i < this->menu.get_num_pizzas(); i++)
	{
		this->menu.get_pizzas()[i].populate_pizza(fin);
	}
	fin.close();
}

void Restaurant::load_employees()
{
	ifstream fin;
	fin.open("employee.txt");
	int trash;
	fin >> trash;
	if (!fin.is_open())
	{
		cout << "Could not open employee file" << endl;
	}
	this->employees = new employee[this->get_num_employees()];
	for (int i = 0; i < this->get_num_employees(); ++i)
	{
		fin >> this->employees[i].id >> this->employees[i].password >> this->employees[i].first_name >> this->employees[i].last_name;
	}
	fin.close();
}

void Restaurant::load_restaurant_info()
{
	ifstream fin;
	fin.open("restaurant_info.txt");
	if (!fin.is_open())
	{
		cout << "could not open rest info file" << endl;
	}
	getline(fin, this->name);
	getline(fin, this->phone);
	getline(fin, this->address);
	int num_hours_total;
	fin >> num_hours_total;
	this->week = new hours[num_hours_total];
	for (int i = 0; i < num_hours_total; i++)
	{
		fin >> this->week[i].day >> this->week[i].open_hour >> this->week[i].close_hour;
	}
	fin.close();
}

void Restaurant::load_orders()
{
	int num_orders;
	ifstream fin;
	fin.open("orders.txt");
	fin >> this->num_orders;
	this->orders = new order[this->num_orders];
	for (int i = 0; i < num_orders; ++i)
	{
		fin >> orders[i].number >> orders[i].name >> orders[i].card_number >> orders[i].phone;
		getline(fin, orders[i].items); 
	}
	fin.close();
}

void Restaurant::view_menu()
{
	for (int i = 0; i < this->menu.get_num_pizzas(); i++)
	{
		cout << this->menu.get_pizzas()[i].get_name() << " " << this->menu.get_pizzas()[i].get_small_cost() << " " << this->menu.get_pizzas()[i].get_medium_cost();
		cout << " " << this->menu.get_pizzas()[i].get_large_cost() << " " << this->menu.get_pizzas()[i].get_num_ingredients();
		for (int j = 0; j < this->menu.get_pizzas()[i].get_num_ingredients(); ++j)
		{
			cout << " " << this->menu.get_pizzas()[i].get_ingredients()[j];
		}
		cout << endl;
	}
}

void Restaurant::view_hours()
{
	for (int i = 0; i < this->get_num_hours(); ++i)
	{
		cout << this->week[i].day << " " << this->week[i].open_hour << " " << this->week[i].close_hour << endl;
	}
}

void Restaurant::view_orders()
{
	for (int i = 0; i < this->get_num_orders(); ++i)
	{
		cout << this->orders[i].number << " " << this->orders[i].name << " " << this->orders[i].card_number << " " << this->orders[i].phone;
		cout << " " << this->orders[i].items << endl;
	}
}

void Restaurant::view_address()
{
	cout << this->address << endl;
}

void Restaurant::view_phone()
{
	cout << this->phone << endl;
}

int Restaurant::view_employee_options()
{
	int num;
	cout << "What would you like to do?" << endl;
	cout << "1) Change hours" << endl;
	cout << "2) View orders" << endl;
	cout << "3) Remove order" << endl;
	cout << "4) Add item to menu" << endl;
	cout << "5) Remove item from menu" << endl;
	cout << "6) View menu" << endl;
	cout << "7) View hours" << endl;
	cout << "8) View address" << endl;
	cout << "9) View phone" << endl;
	cout << "10) Log out" << endl;
	cin >> num;
	return num;
}

int Restaurant::view_customer_options()
{
	int num;
	cout << "What would you like to do?" << endl;
	cout << "1) View menu" << endl;
	cout << "2) Search by cost" << endl;
	cout << "3) Search by ingredients" << endl;
	cout << "4) Place order" << endl;
	cout << "5) View hours" << endl;
	cout << "6) View address" << endl;
	cout << "7) View phone" << endl;
	cout << "8) Log out" << endl;
	cin >> num;
	return num;
}

//over 15 lines because if multiple if statements
void Restaurant::base_login()
{
	bool again = true;
	while (again)
	{
		int num = this->welcome();
		if (num == 1)
		{
			this->run_customer();
		}
		else if (num == 2)
		{
			this->run_employee();
		}
		else if (num == 3)
		{
			again = false;
		}
		else 
		{
			cout << "Please enter a valid input" << endl;
		}
	}
}

//over 15 lines because of multiple if statements
void Restaurant::run_customer()
{
	bool again = true;
	while (again)
	{
		int num = this->view_customer_options();
		if (num == 1)
		{
			this->view_menu();
		}
		else if (num == 2)
		{
			this->search_menu_by_price();
		}
		else if (num == 3)
		{
			this->search_by_ingredients();
		}
		else if (num == 4)
		{
			Pizza * p;
			string * s;
			this->place_order(p, this->number_pizzas_ordered(), s, this->menu);
			this->write_orders();
		}
		else if (num == 5)
		{
			this->view_hours();
		}
		else if (num == 6)
		{
			this->view_address();
		}
		else if (num == 7)
		{
			this->view_phone();
		}
		else
		{
			again = false;
		}
	}
}

//over 15 lines because of multiple if statements
void Restaurant::run_employee()
{
	bool logged_in = this->login(1, " ");
	while (logged_in)
	{
		int num = this->view_employee_options();
		if (num == 1)
		{
			this->change_hours();
			this->write_hours();
		}
		else if (num == 2)
		{
			this->view_orders();
			this->write_orders();
		}
		else if (num == 3)
		{
			this->remove_orders();
			this->write_orders();
		}
		else if (num == 4)
		{
			this->menu.add_to_menu(this->menu.create_new_pizza());
			this->write_menu();
		}
		else if (num == 5)
		{
			this->remove_from_menu();
			this->write_menu();
		}
		else if (num == 6)
		{
			this->view_menu();
		}
		else if (num == 7)
		{
			this->view_hours();
		}
		else if (num == 8)
		{
			this->view_address();
		}
		else if (num == 9)
		{
			this->view_phone();
		}
		else 
		{
			logged_in = false;
		}
	}
}

int Restaurant::welcome()
{
	int answer;
	cout << "Welcome to " << this->name << endl;
	cout << "Are you a Customer (1), Employee (2), or would you like to quit (3)" << endl;
	cin >> answer;
	return answer;
}

//over 15 lines because it has to handle user input
bool Restaurant::login(int id, string password)
{
	while (1)
	{
		cout << "Please enter your ID:" << endl;
		cin >> id;
		while (cin.fail())
        {
	 		cin.clear();
	 		cin.ignore(256, '\n'); //ignores previous cin statement so new one can be made
	 		cout << "Please enter an ID that is only integers" << endl;
	 		cin >> id;
        }
		cout << "Please enter your password:" << endl;
		cin >> password;
		for (int i = 0; i < this->get_num_employees(); ++i)
		{
			if (id == this->employees[i].id && password == this->employees[i].password)
			{
				cout << "Welcome " << this->employees[i].first_name << " " << this->employees[i].last_name << endl;
				return true;
			}
		}
		cout << "Incorrect ID or password, please try again" << endl;
	}
}

void Restaurant::change_hours()
{
	string temp;
	cout << "What day would you like to change the hours for?" << endl;
	cin >> temp;
	for (int i = 0; i < this->get_num_hours(); ++i)
	{
		if (this->week[i].day == temp)
		{
			cout << "What would you like the opening time to be?" << endl;
			cin >> this->week[i].open_hour;
			cout << "What would you like the closing time to be?" << endl;
			cin >> this->week[i].close_hour;
		}
	}
	cout << endl;
	this->view_hours();
}

void Restaurant::write_hours()
{
	ofstream fout;
	fout.open("restaurant_info.txt", ios::trunc);
	fout << this->name << endl;
	fout << this->phone << endl;
	fout << this->address << endl;
	fout << this->get_num_hours() << endl;
	for (int i = 0; i < this->get_num_hours(); ++i)
	{
		fout << this->week[i].day << " " << this->week[i].open_hour << " " << this->week[i].close_hour << endl;
	}
	fout.close();
}


void Restaurant::write_menu()
{
	ofstream fout;
	fout.open("menu.txt", ios::trunc);
	fout << this->menu.get_num_pizzas() << endl;
	for (int i = 0; i < this->menu.get_num_pizzas(); ++i)
	{
		fout << this->menu.get_pizzas()[i].get_name() << " " << this->menu.get_pizzas()[i].get_small_cost();
		fout << " " << this->menu.get_pizzas()[i].get_medium_cost() << " " << this->menu.get_pizzas()[i].get_large_cost();
		fout << " " << this->menu.get_pizzas()[i].get_num_ingredients();
		for (int j = 0; j < this->menu.get_pizzas()[i].get_num_ingredients(); ++j)
		{
			fout << " " << this->menu.get_pizzas()[i].get_ingredients()[j];
		}
		fout << endl;
	}
}

void Restaurant::write_orders()
{
	ofstream fout;
	fout.open("orders.txt", ios::trunc);
	if (!fout.is_open())
	{
		cout << "Did not open orders file" << endl;
	}
	fout << this->num_orders << endl;
	for (int i = 0; i < this->num_orders; ++i)
	{
		fout << this->orders[i].number << " " << this->orders[i].name << " " << this->orders[i].card_number << " " << this->orders[i].phone;
		fout << " " << this->orders[i].items << endl;
	}
	fout.close();
}

void Restaurant::remove_from_menu()
{
	string name;
	cout << "What is the name of the pizza you would like to remove?" << endl;
	cin >> name;
	this->menu.remove_from_menu(name);
}

int Restaurant::order_removal_num()
{
	int num;
	cout << "What order number would you like to remove?" << endl;
	cin >> num;
	return num;
}

void Restaurant::remove_orders()
{
	int index = -1;
	int num = order_removal_num();
	for (int i = 0; i < this->get_num_orders(); ++i)
	{
		if (this->orders[i].number == num)
		{
			index = i;
		}
	}
	if (index == -1)
	{
		cout << "No order matches that number" << endl;
		return;
	}
	for (int i = index; i < this->get_num_orders() - 1; ++i)
	{
		this->orders[i] = this->orders[i + 1];
	}
	this->num_orders--;
}

void Restaurant::add_order(order o)
{
	order * o_temp = new order[this->num_orders + 1];
	for (int i = 0; i < this->num_orders; ++i)
	{
		o_temp[i] = this->orders[i];
	}
	o_temp[this->num_orders] = o;
	if (this->orders != NULL)
	{
		delete [] this->orders;
	}
	this->orders = o_temp;
	this->num_orders++;
}

order Restaurant::create_new_order(string items)
{
	order o;
	cout << "What is the name on this order?" << endl;
	cin >> o.name;
	cout << "What is the credit card number for this order?" << endl;
	cin >> o.card_number;
	cout << "What is the phone number for this order?" << endl;
	cin >> o.phone;
	o.items = items;
	return o;
}

int Restaurant::number_pizzas_ordered()
{
	int num;
	cout << "How many types of pizza would you like to order?" << endl;
	cin >> num;
	return num;
}

//over 15 lines because it has to handle user input, and it also has to initialize a new object and delete memory
void Restaurant::place_order(Pizza * selection, int selection_size, string * num_ordered, Menu & m)
{
	selection = new Pizza[selection_size];
	num_ordered = new string[selection_size];
	string * sizes = new string[selection_size];
	m.print_search_menu();
	string name;
	int j = 0;
	while (j < selection_size)
	{
		cout << "Please enter the name of the item you would like to order.";
		cout << " You may enter cancel to cancel the order" << endl;
		cin >> name;
		for (int i = 0; i < m.get_num_pizzas(); ++i)
		{
			if (name == m.get_pizzas()[i].get_name())
			{
				string num;
				string size;
				cout << "What size would you like this to be (S, M, or L?" << endl;
				cin >> size;
				cout << "How many " << m.get_pizzas()[i].get_name() << "?" << endl;
				cin >> num;
				selection[j] = m.get_pizzas()[i];
				num_ordered[j] = num;
				sizes[j] = size;
				j++;
			}
			else if (name == "cancel")
			{
				return;
			}
		}
	}
	order o;
	cout << "What is the name on this order?" << endl;
	cin >> o.name;
	cout << "What is the credit card number for this order?" << endl;
	cin >> o.card_number;
	cout << "What is the phone number for this order?" << endl;
	cin >> o.phone;
	for (int i = 0; i < selection_size; ++i)
	{
		string o_terms = selection[i].get_name() + " " + sizes[i] + " " + num_ordered[i] + " ";
		o.items += o_terms;
	}
	o.number = this->num_orders + 1;
	this->add_order(o);
	delete [] selection;
	delete [] sizes;
	delete [] num_ordered;
}

//over 15 lines because of different aspects to it
void Restaurant::search_by_ingredients()
{
	int answer;
	int answer2;
	cout << "Would you like to search for ingredients to include (1) or exclude (2)?" << endl;
	cin >> answer;
	if (answer == 1)
	{
		Menu m = this->menu.search_pizza_by_ingredients_to_include();
		m.print_search_menu();
		cout << "Would you like to search further by excluding ingredients? (1) for yes, (2) for no" << endl;
		cin >> answer2;
		if (answer2 == 1)
		{
			Menu m2 = m;
			m = m2.search_pizza_by_ingredients_to_exclude();
		}
		cout << "Here are the pizzas that match your criteria" << endl;
		m.print_search_menu();
		cout << "Would you like to make an order based off this menu? (1) for yes, (2) for no" << endl;
		cin >> answer;
		if (answer == 1)
		{
			Pizza * p;
			string * s;
			this->place_order(p, this->number_pizzas_ordered(), s, m);
			this->write_orders();
		}
	}
	else if (answer == 2)
	{
		Menu m = this->menu.search_pizza_by_ingredients_to_exclude();
		m.print_search_menu();
		cout << "Would you like to search further by including ingredients? (1) for yes, (2) for no" << endl;
		cin >> answer2;
		if (answer2 == 1)
		{
			Menu m2 = m;
			m = m2.search_pizza_by_ingredients_to_include();
		}
		cout << "Here are the pizzas that match your criteria" << endl;
		m.print_search_menu();
		cout << "Would you like to make an order based off this menu? (1) for yes, (2) for no" << endl;
		cin >> answer;
		if (answer == 1)
		{
			Pizza * p;
			string * s;
			this->place_order(p, this->number_pizzas_ordered(), s, m);
			this->write_orders();
		}
	}

}

void Restaurant::search_menu_by_price()
{
	int budget;
	int answer;
	cout << "What is your budget for today (in dollars)?" << endl;
	cin >> budget;
	Menu m;
	m = this->menu.search_pizza_by_cost(budget);
	cout << "Here are the pizzas that match your criteria" << endl;
	m.print_search_menu();
	cout << "Would you like to make an order based off this menu? (1) for yes, (2) for no" << endl;
	cin >> answer;
	if (answer == 1)
	{
		Pizza * p;
		string * s;
		this->place_order(p, this->number_pizzas_ordered(), s, m);
		this->write_orders();
	}
}
