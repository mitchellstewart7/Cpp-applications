#include <iostream>
#include <string>
#include <cstdlib>
#include "animal.h"
#include "sea_otter.h"

using namespace std;

/******************************************************
** Program: sea_otter.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Default constructor
** Input: None
** Output: None
******************************************************/
Sea_otter::Sea_otter()
{
	this->age = 24;
	this->price = 5000;
	this->baby_num = 2;
	this->food_mult = 2;
	this->revenue = 250;
}

/******************************************************
** Program: sea_otter.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Non-default constructor
** Input: None
** Output: None
******************************************************/
Sea_otter::Sea_otter(int age)
{
	this->age = age;
	this->price = 5000;
	this->baby_num = 2;
	this->food_mult = 2;
	this->revenue = 250;
}

/******************************************************
** Program: sea_otter.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Destructor
** Input: None
** Output: None
******************************************************/
Sea_otter::~Sea_otter()
{}