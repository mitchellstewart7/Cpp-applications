#include <iostream>
#include <string>
#include <cstdlib>
#include "animal.h"
#include "sloth.h"

using namespace std;

/******************************************************
** Program: sloth.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Default constructor
** Input: None
** Output: None
******************************************************/
Sloth::Sloth()
{
	this->age = 24;
	this->price = 2000;
	this->baby_num = 5;
	this->food_mult = 1;
	this->revenue = 100;
}

/******************************************************
** Program: sloth.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Non-default constructor
** Input: None
** Output: None
******************************************************/
Sloth::Sloth(int age)
{
	this->age = age;
	this->price = 2000;
	this->baby_num = 5;
	this->food_mult = 1;
	this->revenue = 100;
}

/******************************************************
** Program: sloth.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Destructor
** Input: None
** Output: None
******************************************************/
Sloth::~Sloth()
{}