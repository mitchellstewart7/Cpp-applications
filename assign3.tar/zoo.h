#ifndef ZOO_H
#define ZOO_H

#include <iostream>
#include <string>
#include "animal.h"
#include "monkey.h"
#include "sloth.h"
#include "sea_otter.h"
#include "human.h"

using namespace std;

class Zoo 
{
private:
	Monkey * monkeys;
	int num_monkeys;
	Sloth * sloths;
	int num_sloths;
	Sea_otter * sea_otters;
	int num_sea_otters;
	Human * humans;
	int num_humans;
	int bank_account;
	int num_months;
	int base_cost;
public:
	//constructor
	Zoo();
	//destructor
	~Zoo();
	//copy constructor
	Zoo(const Zoo & zoo);
	//assignment operator overload
	Zoo & operator=(const Zoo & zoo);

	//getters
	int get_num_monkeys();
	int get_num_sloths();
	int get_num_sea_otters();
	int get_num_humans();
	int get_bank_account();
	int get_num_months();
	int get_base_cost();
	Monkey * get_monkeys();

	//find numbers of animals of certain age range
	int num_adult_monkeys();
	int num_adult_sloths();
	int num_adult_sea_otters();
	int num_adult_humans();
	int num_baby_monkeys();
	int num_baby_sloths();
	int num_baby_sea_otters();
	int num_baby_humans();

	//setters

	//create functions
	Monkey create_monkey();
	Sloth create_sloth();
	Sea_otter create_sea_otter();
	Human create_human();
	Monkey create_baby_monkey();
	Sloth create_baby_sloth();
	Sea_otter create_baby_sea_otter();
	Human create_baby_human();


	//add functions
	void add_monkey(Monkey monkey);
	void add_sloth(Sloth sloth);
	void add_sea_otter(Sea_otter sea_otter);
	void add_human(Human human);

	//remove functions
	void remove_monkey(int num);
	void remove_sloth(int num);
	void remove_sea_otter(int num);
	void remove_human(int num);

	//add_month
	void add_month();

	//recieves monthly revenue
	void add_monthly_revenue();
	int add_monkey_revenue();
	int add_sloth_revenue();
	int add_sea_otter_revenue();
	int add_human_revenue();

	//buying an animal
	void buy_animal();
	void buy_monkey();
	void buy_sloth();
	void buy_sea_otter();
	void buy_human();

	//selling an animal
	void sell_animal();
	void sell_monkey();
	void sell_sloth();
	void sell_sea_otter();
	void sell_human();

	//special events
	void special_event();
	void animal_sick();
	void animal_baby();
	void attendance_boom();

	//animal sick
	void monkey_sick();
	void sloth_sick();
	void sea_otter_sick();
	void human_sick();

	//feeding
	void feed_cost();
	void base_cost_change();

	//prints all animals in zoo
	void print_zoo();

	//runs through one month of play
	void run_month();
	void start_screen();

	//test for bankrupt
	bool test_bankrupt();

	//display infomration
	void display_month_account();


};

#endif