#ifndef HUMAN_H
#define HUMAN_H

#include <iostream>
#include <string>
#include "animal.h"

using namespace std;

class Human : public Animal
{
private:
public:
	Human();
	Human(int age);
	~Human();
};

#endif