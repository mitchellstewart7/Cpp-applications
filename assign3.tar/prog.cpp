#include <iostream>
#include <cstdlib>
#include <string>
#include "zoo.h"
#include "animal.h"
#include "monkey.h"
#include "sloth.h"
#include "sea_otter.h"
#include "human.h"
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
	srand(time(NULL)); //seed random number generator
	bool bankrupt = false;
	Zoo z;
	z.start_screen();
	z.print_zoo();
	while (!bankrupt)
	{
		int answer;
		cout << endl;
		cout << "Enter 1 to progress to the next month, 2 to quit" << endl;
		cin >> answer;
		if (answer == 1)
		{
			z.run_month();
			bankrupt = z.test_bankrupt();
		}
		else 
		{
			return 1;
		}
	}
	return 1;
}