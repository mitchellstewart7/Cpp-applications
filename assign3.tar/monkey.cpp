#include <iostream>
#include <string>
#include <cstdlib>
#include "animal.h"
#include "monkey.h"

using namespace std;

/******************************************************
** Program: monkey.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Default constructor
** Input: None
** Output: None
******************************************************/
Monkey::Monkey()
{
	this->age = 24;
	this->price = 15000;
	this->baby_num = 1;
	this->food_mult = 4;
	this->revenue = 1500;
}

/******************************************************
** Program: monkey.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Non-default constructor
** Input: None
** Output: None
******************************************************/
Monkey::Monkey(int age)
{
	this->age = age;
	this->price = 15000;
	this->baby_num = 1;
	this->food_mult = 4;
	this->revenue = 1500;
}

/******************************************************
** Program: monkey.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Destructor
** Input: None
** Output: None
******************************************************/
Monkey::~Monkey()
{}