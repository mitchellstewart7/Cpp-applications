#include <iostream>
#include <string>
#include <cstdlib>
#include "zoo.h"
#include "animal.h"
#include "monkey.h"
#include "sloth.h"
#include "sea_otter.h"
#include "human.h"
#include <ctime>
#include <math.h>

using namespace std;

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: default constructor
** Input: None
** Output: None, but sets up default values for zoo
******************************************************/
Zoo::Zoo()
{
	this->monkeys = NULL;
	this->num_monkeys = 0;
	this->sloths = NULL;
	this->num_sloths = 0;
	this->sea_otters = NULL;
	this->num_sea_otters = 0;
	this->humans = NULL;
	this->num_humans = 0;
	this->bank_account = 50000;
	this->num_months = 1;
	this->base_cost = 100;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Destructor, frees memory
** Input: None
** Output: None
******************************************************/
Zoo::~Zoo()
{
	if (this->monkeys != NULL)
	{
		delete [] this->monkeys;
		this->monkeys = NULL;
	}
	if (this->sloths != NULL)
	{
		delete [] this->sloths;
		this->sloths = NULL;
	}
	if (this->sea_otters != NULL)
	{
		delete [] this->sea_otters;
		this->sea_otters = NULL;
	}
	if (this->humans != NULL)
	{
		delete [] this->humans;
		this->humans = NULL;
	}
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Copy constructor
** Input: Zoo object
** Output: new Zoo object with same values
******************************************************/
//over 15 lines because it is the copy constructor, deals with lots of for loops and memory allocation
Zoo::Zoo(const Zoo & zoo)
{
	this->num_monkeys = zoo.num_monkeys;
	this->num_sloths = zoo.num_sloths;
	this->num_sea_otters = zoo.num_sea_otters;
	this->num_humans = zoo.num_humans;
	this->bank_account = zoo.bank_account;
	this->num_months = zoo.num_months;
	this->base_cost = zoo.base_cost;
	this->monkeys = new Monkey[this->num_monkeys];
	for (int i = 0; i < this->num_monkeys; ++i)
	{
		this->monkeys[i] = zoo.monkeys[i];
	}
	this->sloths = new Sloth[this->num_sloths];
	for (int i = 0; i < this->num_sloths; ++i)
	{
		this->sloths[i] = zoo.sloths[i];
	}
	this->sea_otters = new Sea_otter[this->num_sea_otters];
	for (int i = 0; i < this->num_sea_otters; ++i)
	{
		this->sea_otters[i] = zoo.sea_otters[i];
	}
	this->humans = new Human[this->num_humans];
	for (int i = 0; i < this->num_humans; ++i)
	{
		this->humans[i] = zoo.humans[i];
	}
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Assignment operator overload
** Input: Zoo object
** Output: Zoo object
******************************************************/
//over 15 lines because it is AOO, deals with lots of for loops and memory allocation
Zoo & Zoo::operator=(const Zoo & zoo)
{
	if (this != &zoo)
	{
		this->num_monkeys = zoo.num_monkeys;
		this->num_sloths = zoo.num_sloths;
		this->num_sea_otters = zoo.num_sea_otters;
		this->bank_account = zoo.bank_account;
		this->num_months = zoo.num_months;
		this->base_cost = zoo.base_cost;
		this->monkeys = new Monkey[this->num_monkeys];
		for (int i = 0; i < this->num_monkeys; ++i)
		{
			this->monkeys[i] = zoo.monkeys[i];
		}
		this->sloths = new Sloth[this->num_sloths];
		for (int i = 0; i < this->num_sloths; ++i)
		{
			this->sloths[i] = zoo.sloths[i];
		}
		this->sea_otters = new Sea_otter[this->num_sea_otters];
		for (int i = 0; i < this->num_sea_otters; ++i)
		{
			this->sea_otters[i] = zoo.sea_otters[i];
		}
		this->humans = new Human[this->num_humans];
		for (int i = 0; i < this->num_humans; ++i)
		{
			this->humans[i] = zoo.humans[i];
		}
	}
	return *this;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Getters, access variables
** Input: None
** Output: Value
******************************************************/
int Zoo::get_bank_account()
{
	return this->bank_account;
}

int Zoo::get_base_cost()
{
	return this->base_cost;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Create new objects of their respective classes
** Input: None
** Output: Object of the class
******************************************************/
Monkey Zoo::create_monkey()
{
	Monkey m;
	return m;
}

Sloth Zoo::create_sloth()
{
	Sloth s;
	return s;
}

Sea_otter Zoo::create_sea_otter()
{
	Sea_otter sea;
	return sea;
}

Human Zoo::create_human()
{
	Human h;
	return h;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Create non-default object of their classes
** Input: None
** Output: Objects of the class
******************************************************/
Monkey Zoo::create_baby_monkey()
{
	Monkey m(0);
	return m;
}

Sloth Zoo::create_baby_sloth()
{
	Sloth s(0);
	return s;
}

Sea_otter Zoo::create_baby_sea_otter()
{
	Sea_otter sea(0);
	return sea;
}

Human Zoo::create_baby_human()
{
	Human h(0);
	return h;
}


/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Adds the object to the array of objects of that class
** Input: Object
** Output: None
******************************************************/
void Zoo::add_monkey(Monkey monkey)
{
	Monkey * m_temp = new Monkey[this->num_monkeys + 1];
	for (int i = 0; i < this->num_monkeys; ++i)
	{
		m_temp[i] = this->monkeys[i];
	}
	m_temp[this->num_monkeys] = monkey;
	if (this->monkeys != NULL)
	{
		delete [] this->monkeys;
	}
	this->monkeys = m_temp;
	this->num_monkeys++;
}

void Zoo::add_sloth(Sloth sloth)
{
	Sloth * s_temp = new Sloth[this->num_sloths + 1];
	for (int i = 0; i < this->num_sloths; ++i)
	{
		s_temp[i] = this->sloths[i];
	}
	s_temp[this->num_sloths] = sloth;
	if (this->sloths != NULL)
	{
		delete [] this->sloths;
	}
	this->sloths = s_temp;
	this->num_sloths++;
}

void Zoo::add_sea_otter(Sea_otter sea)
{
	Sea_otter * s_temp = new Sea_otter[this->num_sea_otters + 1];
	for (int i = 0; i < this->num_sea_otters; ++i)
	{
		s_temp[i] = this->sea_otters[i];
	}
	s_temp[this->num_sea_otters] = sea;
	if (this->sea_otters != NULL)
	{
		delete [] this->sea_otters;
	}
	this->sea_otters = s_temp;
	this->num_sea_otters++;
}

void Zoo::add_human(Human human)
{
	Human * h_temp = new Human[this->num_humans + 1];
	for (int i = 0; i < this->num_humans; ++i)
	{
		h_temp[i] = this->humans[i];
	}
	h_temp[this->num_humans] = human;
	if (this->humans != NULL)
	{
		delete [] this->humans;
	}
	this->humans = h_temp;
	this->num_humans++;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Adds one month of age to each object
** Input: None
** Output: None
******************************************************/
void Zoo::add_month()
{
	for (int i = 0; i < num_monkeys; i++)
	{
		monkeys[i].set_age(monkeys[i].get_age() + 1);
	}
	for (int i = 0; i < num_sea_otters; i++)
	{
		sea_otters[i].set_age(sea_otters[i].get_age() + 1);
	}
	for (int i = 0; i < num_sloths; i++)
	{
		sloths[i].set_age(sloths[i].get_age() + 1);
	}
	for (int i = 0; i < num_humans; i++)
	{
		humans[i].set_age(humans[i].get_age() + 1);
	}
	cout << "All animals have aged by one month\n" << endl;
	this->print_zoo();
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Calculates monthly revenue and adds it to bank account
** Input: None
** Output: None
******************************************************/
void Zoo::add_monthly_revenue()
{
	int total;
	total = this->add_monkey_revenue() + this->add_sloth_revenue() + this->add_sea_otter_revenue() + this->add_human_revenue();
	this->bank_account += total;
	cout << "You have collected revenue from your animals, it came out to $" << total << endl;
	cout << "Bank account balance: $" << this->bank_account << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Calculate revenue of each type of object
** Input: None
** Output: Int representing the revenue of that type of object
******************************************************/
int Zoo::add_monkey_revenue()
{
	int total = 0;
	for (int i = 0; i < num_monkeys; i++)
	{
		if (monkeys[i].get_age() < 6)
		{
			total += monkeys[i].get_revenue() * 2;
		}
		else 
		{
			total += monkeys[i].get_revenue();
		}
	}
	return total;
}

int Zoo::add_sloth_revenue()
{
	int total = 0;
	for (int i = 0; i < num_sloths; i++)
	{
		if (sloths[i].get_age() < 6)
		{
			total += sloths[i].get_revenue() * 2;
		}
		else 
		{
			total += sloths[i].get_revenue();
		}
	}
	return total;
}

int Zoo::add_sea_otter_revenue()
{
	int total = 0;
	for (int i = 0; i < num_sea_otters; i++)
	{
		if (sea_otters[i].get_age() < 6)
		{
			total += sea_otters[i].get_revenue() * 2;
		}
		else 
		{
			total += sea_otters[i].get_revenue();
		}
	}
	return total;
}

int Zoo::add_human_revenue()
{
	int total = 0;
	for (int i = 0; i < num_humans; i++)
	{
		if (humans[i].get_age() < 6)
		{
			total += humans[i].get_revenue() * 2;
		}
		else 
		{
			total += humans[i].get_revenue();
		}
	}
	return total;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Deals with the purchase of an animal
** Input: None
** Output: None
******************************************************/
//over 15 lines because of the while loop, and mulitiple if statements
void Zoo::buy_animal()
{
	int answer;
	cout << "Would you like to buy an animal (1 for yes, 2 for no)?" << endl;
	cin >> answer;
	if (answer == 1)
	{
		bool again = true;
		while (again)
		{
			string type;
			cout << "What type of animal would you like to buy: monkey ($15000), sloth ($2000), sea_otter ($5000), or human ($30000)?" << endl;
			cin >> type;
			if (type == "monkey")
			{
				this->buy_monkey();
				again = false;
			}
			else if (type == "sloth")
			{
				this->buy_sloth();
				again = false;
			}
			else if (type == "sea_otter")
			{
				this->buy_sea_otter();
				again = false;
			}
			else if (type == "human")
			{
				this->buy_human();
				again = false;
			}
			else
			{
				cout << "No animal matches this description, please try again" << endl;
			}
		}
	}
	else //user does not want to buy an animal
	{
		cout << "No animals are bought for this month" << endl;
	}
	cout << "Bank account balance: $" << this->bank_account << "\n" << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Adds the chosen number of objects to their array
** Input: None
** Output: None
******************************************************/
void Zoo::buy_monkey()
{
	int num;
	cout << "Would you like to buy 1 (1) or 2 (2)?" << endl;
	cin >> num;
	for (int i = 0; i < num; ++i)
	{
		this->add_monkey(this->create_monkey());
		this->bank_account -= this->monkeys[i].get_price();
	}
}

void Zoo::buy_sloth()
{
	int num;
	cout << "Would you like to buy 1 (1) or 2 (2)?" << endl;
	cin >> num;
	for (int i = 0; i < num; ++i)
	{
		this->add_sloth(this->create_sloth());
		this->bank_account -= this->sloths[i].get_price();
	}
}

void Zoo::buy_sea_otter()
{
	int num;
	cout << "Would you like to buy 1 (1) or 2 (2)?" << endl;
	cin >> num;
	for (int i = 0; i < num; ++i)
	{
		this->add_sea_otter(this->create_sea_otter());
		this->bank_account -= this->sea_otters[i].get_price();
	}
}

void Zoo::buy_human()
{
	int num;
	cout << "Would you like to buy 1 (1) or 2 (2)?" << endl;
	cin >> num;
	for (int i = 0; i < num; ++i)
	{
		this->add_human(this->create_human());
		this->bank_account -= this->humans[i].get_price();
	}
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Prints out the arrays of objects and their ages
** Input: None
** Output: None
******************************************************/
//over 15 lines because of many if statements and for loops which are necessary for printing a useful statement
void Zoo::print_zoo()
{	
	cout << "Monkeys in your zoo, and their ages (in months):" << endl;
	if (num_monkeys != 0)
	{
		for (int i = 0; i < this->num_monkeys; ++i)
		{
			cout << "Monkey " << i + 1 << ", Age: " << this->monkeys[i].get_age() << endl;
		}
	}
	else 
	{
		cout << "None" << endl;
	}
	cout << "Sloths in your zoo, and their ages:" << endl;
	if (num_sloths != 0)
	{
		for (int i = 0; i < this->num_sloths; ++i)
		{
			cout << "Sloth " << i + 1 << ", Age: " << this->sloths[i].get_age() << endl;
		}
	}
	else
	{
		cout << "None" << endl;
	}
	cout << "Sea otters in your zoo, and their ages:" << endl;
	if (num_sea_otters != 0)
	{
		for (int i = 0; i < this->num_sea_otters; ++i)
		{
			cout << "Sea otter " << i + 1 << ", Age: " << this->sea_otters[i].get_age() << endl;
		}
	}
	else
	{
		cout << "None" << endl;
	}
	cout << "Humans in your zoo, and their ages:" << endl;
	if (num_humans != 0)
	{
		for (int i = 0; i < this->num_humans; ++i)
		{
			cout << "Human " << i + 1 << ", Age: " << this->humans[i].get_age() << endl;
		}
	}
	else
	{
		cout << "None" << endl;
	}
	cout << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Deals with the selling of the selected type of animal
** Input: None
** Output: None
******************************************************/
//over 15 lines because of many if statements for each type of object
void Zoo::sell_animal()
{
	int answer;
	cout << "Would you like to sell an animal (1 for yes, 2 for no)?" << endl;
	cin >> answer;
	if (answer == 1)
	{
		bool again = true;
		while (again)
		{
			string type;
			cout << "What type of animal would you like to sell (monkey, sloth, sea_otter, or human)?" << endl;
			cin >> type;
			if (type == "monkey" && num_monkeys > 0)
			{
				this->sell_monkey();
				again = false;
			}
			else if (type == "sloth" && num_sloths > 0)
			{
				this->sell_sloth();
				again = false;
			}
			else if (type == "sea_otter" && num_sea_otters > 0)
			{
				this->sell_sea_otter();
				again = false;
			}
			else if (type == "human" && num_humans > 0)
			{
				this->sell_human();
				again = false;
			}
			else
			{
				cout << "No such animal exists, or there are none in your zoo" << endl;
			}
		}
	}
	else //user does not want to sell an animal
	{
		cout << "No animals are sold for this month" << endl;
	}
	cout << "Bank account balance $" << this->bank_account << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Removes the object from its array and adds to bank account
** Input: None
** Output: None
******************************************************/
void Zoo::sell_monkey()
{
	this->remove_monkey(0);
	cout << "1 monkey has been sold" << endl;
	this->bank_account += (monkeys[0].get_price() / 2);
}

void Zoo::sell_sloth()
{
	this->remove_sloth(0);
	cout << "1 sloth has been sold" << endl;
	this->bank_account += (sloths[0].get_price() / 2);
}

void Zoo::sell_sea_otter()
{
	this->remove_sea_otter(0);
	cout << "1 sea otter has been sold" << endl;
	this->bank_account += (sea_otters[0].get_price() / 2);
}

void Zoo::sell_human()
{
	this->remove_human(0);
	cout << "1 human has been sold" << endl;
	this->bank_account += (humans[0].get_price() / 2);
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Removes object from its array
** Input: None
** Output: None
******************************************************/
void Zoo::remove_monkey(int num)
{
	for (int i = num; i < this->num_monkeys - 1; ++i)
	{
		this->monkeys[i] = this->monkeys[i + 1];
	}
	this->num_monkeys--;
}

void Zoo::remove_sloth(int num)
{
	for (int i = num; i < this->num_sloths - 1; ++i)
	{
		this->sloths[i] = this->sloths[i + 1];
	}
	this->num_sloths--;
}

void Zoo::remove_sea_otter(int num)
{
	for (int i = num; i < this->num_sea_otters - 1; ++i)
	{
		this->sea_otters[i] = this->sea_otters[i + 1];
	}
	this->num_sea_otters--;
}

void Zoo::remove_human(int num)
{
	for (int i = num; i < this->num_humans - 1; ++i)
	{
		this->humans[i] = this->humans[i + 1];
	}
	this->num_humans--;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Picks random special event and executes it
** Input: None
** Output: None
******************************************************/
void Zoo::special_event()
{
	int num = rand() % 4;
	if (num == 0)
	{
		this->animal_baby();
	}
	else if (num == 1)
	{
		this->animal_sick();
	}
	else if (num == 2)
	{
		this->attendance_boom();
	}
	else 
	{
		cout << "No special event occured this month" << endl;
	}
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Generates a random baby
** Input: None
** Output: None
******************************************************/
//over 15 lines because of if statements for every animal type
void Zoo::animal_baby()
{
	bool again = true;
	cout << "Special event: Baby/babies is/are born" << endl;
	while (again)
	{
		int num = rand() % 4;
		if (num_monkeys == 0 && num_sloths == 0 && num_sea_otters == 0 && num_humans == 0) 
		{
			cout << "No animals could give birth because there are no animals" << endl;
			again = false;
		}
		else if (num == 0 && this->num_adult_monkeys() > 0)
		{
			cout << "Baby monkey added to the zoo" << endl;
			this->add_monkey(create_baby_monkey());
			again = false;
		}
		else if (num == 1 && this->num_adult_sloths() > 0)
		{
			cout << "Baby sloths added to the zoo" << endl;
			for (int i = 0; i < sloths[0].get_baby_num(); ++i)
			{
				this->add_sloth(create_baby_sloth());
			}
			again = false;
		}
		else if (num == 2 && this->num_adult_sea_otters() > 0)
		{
			cout << "Baby sea otters added to zoo" << endl;
			for (int i = 0; i < sea_otters[0].get_baby_num(); ++i)
			{
				this->add_sea_otter(create_baby_sea_otter());
			}
			again = false;
		}
		else if (num == 3 && this->num_adult_humans() > 0)
		{
			cout << "Baby human added to zoo" << endl;
			for (int i = 0; i < humans[0].get_baby_num(); ++i)
			{
				this->add_human(create_baby_human());
			}
			again = false;
		}
	}
	this->print_zoo();
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Calculates the number of adults of an object type in their array
** Input: None
** Output: Int for the number of adults
******************************************************/
int Zoo::num_adult_monkeys()
{
	int num = 0;
	for (int i = 0; i < num_monkeys; ++i)
	{
		if (monkeys[i].get_age() >= 24)
		{
			num++;
		}
	}
	return num;
}

int Zoo::num_adult_sloths()
{
	int num = 0;
	for (int i = 0; i < num_sloths; ++i)
	{
		if (sloths[i].get_age() >= 24)
		{
			num++;
		}
	}
	return num;
}

int Zoo::num_adult_sea_otters()
{
	int num = 0;
	for (int i = 0; i < num_sea_otters; ++i)
	{
		if (sea_otters[i].get_age() >= 24)
		{
			num++;
		}
	}
	return num;
}

int Zoo::num_adult_humans()
{
	int num = 0;
	for (int i = 0; i < num_humans; ++i)
	{
		if (humans[i].get_age() >= 24)
		{
			num++;
		}
	}
	return num;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Calculates the number of babies of a certain object in its array
** Input: None
** Output: Int for the number of babies
******************************************************/
int Zoo::num_baby_monkeys()
{
	int num = 0;
	for (int i = 0; i < num_monkeys; ++i)
	{
		if (monkeys[i].get_age() < 6)
		{
			num++;
		}
	}
	return num;
}

int Zoo::num_baby_sloths()
{
	int num = 0;
	for (int i = 0; i < num_sloths; ++i)
	{
		if (sloths[i].get_age() < 6)
		{
			num++;
		}
	}
	return num;
}

int Zoo::num_baby_sea_otters()
{
	int num = 0;
	for (int i = 0; i < num_sea_otters; ++i)
	{
		if (sea_otters[i].get_age() < 6)
		{
			num++;
		}
	}
	return num;
}

int Zoo::num_baby_humans()
{
	int num = 0;
	for (int i = 0; i < num_humans; ++i)
	{
		if (humans[i].get_age() < 6)
		{
			num++;
		}
	}
	return num;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Deals with an animal getting sick
** Input: None
** Output: None
******************************************************/
//over 15 lines because of many if statements for each animal type
void Zoo::animal_sick()
{
	bool again = true;
	cout << "Special event: An animal got sick" << endl;
	while (again)
	{
		int num = rand() % 4;
		if (num_monkeys == 0 && num_sloths == 0 && num_sea_otters == 0 && num_humans == 0) 
		{
			cout << "No animals could get sick because there are no animals" << endl;
			again = false;
		}
		else if (num == 0 && this->num_monkeys > 0)
		{
			this->monkey_sick();
			again = false;
		}
		else if (num == 1 && this->num_sloths > 0)
		{
			this->sloth_sick();
			again = false;
		}
		else if (num == 2 && this->num_sea_otters > 0)
		{
			this->sea_otter_sick();
			again = false;
		}
		else if (num == 3 && this->num_humans > 0)
		{
			this->human_sick();
			again = false;
		}
	}
	cout << "Bank account balance: $" << this->bank_account << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Subtracts from bank account to heal animal, or kills it and removes it from the array
** Input: None
** Output: None
******************************************************/
void Zoo::monkey_sick()
{
	int num = rand() % this->num_monkeys;
	if (this->bank_account >= (monkeys[num].get_price() / 2))
	{
		cout << "Monkey got sick, healed for $" << (monkeys[num].get_price() / 2) << endl;
		this->bank_account -= (monkeys[num].get_price() / 2);
	}
	else
	{
		cout << "Monkey got sick and died, not enough money to heal" << endl;
		this->remove_monkey(num);
	}
}

void Zoo::sloth_sick()
{
	int num = rand() % this->num_sloths;
	if (this->bank_account >= (sloths[num].get_price() / 2))
	{
		cout << "Sloth got sick, healed for $" << (sloths[num].get_price() / 2) << endl;
		this->bank_account -= (sloths[num].get_price() / 2);
	}
	else
	{
		cout << "Sloth got sick and died, not enough money to heal" << endl;
		this->remove_sloth(num);
	}
}

void Zoo::sea_otter_sick()
{
	int num = rand() % this->num_sea_otters;
	if (this->bank_account >= (sea_otters[num].get_price() / 2))
	{
		cout << "Sea otter got sick, healed for $" << (sea_otters[num].get_price() / 2) << endl;
		this->bank_account -= (sea_otters[num].get_price() / 2);
	}
	else
	{
		cout << "Sea otter got sick and died, not enough money to heal" << endl;
		this->remove_sea_otter(num);
	}
}

void Zoo::human_sick()
{
	int num = rand() % this->num_humans;
	if (this->bank_account >= (humans[num].get_price() / 2))
	{
		cout << "Human got sick, healed for $" << (humans[num].get_price() / 2) << endl;
		this->bank_account -= (humans[num].get_price() / 2);
	}
	else
	{
		cout << "Human got sick and died, not enough money to heal" << endl;
		this->remove_human(num);
	}
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Handles special event of an attendance boom
** Input: None
** Output: None
******************************************************/
void Zoo::attendance_boom()
{
	int num;
	int total = 0;
	cout << "Special event: attendance boom, each monkey generates random extra revenue" << endl;
	for (int i = 0; i < num_monkeys; ++i)
	{
		num = (300 + rand() % 401);
		this->bank_account += num;
		total += num;
	}
	cout << "Attendance boom earned you $" << total << endl;
	cout << "Bank account balance: $" << this-> bank_account << "\n" << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Calculates the cost of feeding the animals
** Input: None
** Output: None
******************************************************/
//over 15 lines because of for loops for each type of animal
void Zoo::feed_cost()
{
	cout << "Animals are being fed" << endl;
	for (int i = 0; i < num_monkeys; ++i)
	{
		this->bank_account -= (monkeys[i].get_food_mult() * this->base_cost);
	}
	for (int i = 0; i < num_sloths; ++i)
	{
		this->bank_account -= (sloths[i].get_food_mult() * this->base_cost);
	}
	for (int i = 0; i < num_sea_otters; ++i)
	{
		this->bank_account -= (sea_otters[i].get_food_mult() * this->base_cost);
	}
	for (int i = 0; i < num_humans; ++i)
	{
		this->bank_account -= (humans[i].get_food_mult() * this->base_cost);
	}
	this->base_cost_change(); 
	cout << "After paying for food, you now have $" << this->bank_account << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Changes base cost
** Input: None
** Output: None
******************************************************/
void Zoo::base_cost_change()
{
	int num = 75 + (rand() % 51);
	double mult = (double) num / 100;
	this->base_cost = this->base_cost * mult;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Runs one month of the program
** Input: None
** Output: None
******************************************************/
void Zoo::run_month()
{
	this->display_month_account();
	this->add_month();
	cout << endl;
	this->add_monthly_revenue();
	cout << endl;
	this->special_event();
	cout << endl;
	this->buy_animal();
	cout << endl;
	this->sell_animal();
	cout << endl;
	this->feed_cost();
	cout << endl;
	this->num_months++;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Prints start screen, lets user buy animal to begin with
** Input: None
** Output: None
******************************************************/
void Zoo::start_screen()
{
	int answer;
	cout << "Hello, welcome to Zoo Tycoon!" << endl;
	cout << "You are the owner of a zoo trying to maximize profits and not go bankrupt!" << endl;
	cout << "You will progress one month at a time, and will start with $50,000" << endl;
	this->buy_animal();
	cout << endl;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Tests to see if user has gone bankrupt
** Input: None
** Output: Boolean for whether they are bankrupt or not
******************************************************/
bool Zoo::test_bankrupt()
{
	if (this->bank_account <= 0)
	{
		cout << "You have gone bankrupt, game over" << endl;
		return true;
	}
	return false;
}

/******************************************************
** Program: zoo.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Prints current month and bank account balance and numbers of animals
** Input: None
** Output: None
******************************************************/
void Zoo::display_month_account()
{
	cout << endl;
	cout << "Month: " << this->num_months << endl;
	cout << "Bank account balance: $" << this->bank_account << endl;
	cout << "There are " << this->num_adult_monkeys() << " adult monkeys" << endl;
	cout << "There are " << this->num_adult_humans() << " adult humans" << endl;
	cout << "There are " << this->num_adult_sloths() << " adult sloths" << endl;
	cout << "There are " << this->num_adult_sea_otters() << " adult sea otters" << endl;
	cout << "There are " << this->num_baby_monkeys() << " baby monkeys" << endl;
	cout << "There are " << this->num_baby_humans() << " baby humans" << endl;
	cout << "There are " << this->num_baby_sloths() << " baby sloths" << endl;
	cout << "There are " << this->num_baby_sea_otters() << " baby sea otters" << endl;
	cout << endl;
}
