#ifndef SLOTH_H
#define SLOTH_H

#include <iostream>
#include <string>
#include "animal.h"

using namespace std;

class Sloth : public Animal
{
private:
	
public:
	Sloth();
	Sloth(int age);
	~Sloth();
};

#endif