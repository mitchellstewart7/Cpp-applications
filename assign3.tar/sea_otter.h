#ifndef SEA_OTTER_H
#define SEA_OTTER_H

#include <iostream>
#include <string>
#include "animal.h"

using namespace std;

class Sea_otter : public Animal
{
private:
	
public:
	Sea_otter();
	Sea_otter(int age);
	~Sea_otter();
};

#endif