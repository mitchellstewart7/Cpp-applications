#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
#include <string>

using namespace std;

class Animal
{
protected:
	int age;
	int price;
	int baby_num;
	int food_mult;
	int revenue;
public:
	//constructor
	Animal();
	//destructor
	~Animal();

	//getters
	int get_age();
	int get_price();
	int get_baby_num();
	int get_food_mult();
	int get_revenue();

	//setters
	void set_age(int age);
	void set_price(int price);
	void set_baby_num(int baby_num);
	void set_food_mult(int food_mult);
	void set_revenue(int revenue);

};

#endif
