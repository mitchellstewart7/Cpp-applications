#include <iostream>
#include <string>
#include <cstdlib>
#include "animal.h"
#include "human.h"

using namespace std;

/******************************************************
** Program: human.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Default constructor, establishes default values
** Input: None
** Output: None
******************************************************/
Human::Human()
{
	this->age = 24;
	this->price = 30000;
	this->baby_num = 1;
	this->food_mult = 8;
	this->revenue = 6000;
}

/******************************************************
** Program: human.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Non-default constructor
** Input: None
** Output: None
******************************************************/
Human::Human(int age)
{
	this->age = age;
	this->price = 30000;
	this->baby_num = 1;
	this->food_mult = 8;
	this->revenue = 6000;
}

/******************************************************
** Program: human.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Destructor
** Input: None
** Output: None
******************************************************/
Human::~Human()
{}