#include <iostream>
#include <string>
#include <cstdlib>
#include "animal.h"

using namespace std;

/******************************************************
** Program: animal.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Default constructor
** Input: None
** Output: None
******************************************************/
Animal::Animal()
{
	this->age = 24;
	this->price = 0;
	this->baby_num = 0;
	this->food_mult = 0;
	this->revenue = 0;
}

/******************************************************
** Program: animal.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Destructor
** Input: None
** Output: None
******************************************************/
Animal::~Animal()
{}

/******************************************************
** Program: animal.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Gets values for different variables
** Input: None
** Output: Value
******************************************************/
int Animal::get_age()
{
	return this->age;
}
int Animal::get_price()
{
	return this->price;
}
int Animal::get_baby_num()
{
	return this->baby_num;
}
int Animal::get_food_mult()
{
	return this->food_mult;
}
int Animal::get_revenue()
{
	return this->revenue;
}

/******************************************************
** Program: animal.cpp
** Author: Mitchell Stewart
** Date: 05/10/2020
** Description: Sets value of different variables
** Input: Value
** Output: None
******************************************************/
void Animal::set_age(int age)
{
	this->age = age;
}
void Animal::set_price(int price)
{
	this->price = price;
}
void Animal::set_baby_num(int baby_num)
{
	this->baby_num = baby_num;
}
void Animal::set_food_mult(int food_mult)
{
	this->food_mult = food_mult;
}
void Animal::set_revenue(int revenue)
{
	this->revenue = revenue;
}