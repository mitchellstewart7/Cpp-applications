#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>
#include "gold.h"
#include "event.h"

using namespace std;

/*********************************************************************
** Function: gold
** Description: constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new gold object
*********************************************************************/
Gold::Gold()
{
	this->name = "gold";
}

/*********************************************************************
** Function: ~gold
** Description: destructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted object
*********************************************************************/
Gold::~Gold()
{}

/*********************************************************************
** Function: get_name
** Description: gets the name
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: string
*********************************************************************/
string Gold::get_name()
{
	return "gold";
}

/*********************************************************************
** Function: percept
** Description: gold percept
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Gold::percept()
{
	cout << "You see a glimmer nearby" << endl;
}

/*********************************************************************
** Function: encounter
** Description: gold encounter
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Gold::encounter()
{
	cout << "You have found the gold" << endl;
}