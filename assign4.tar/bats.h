#ifndef BATS_H
#define BATS_H

#include <iostream>
#include <cstdlib>
#include <vector>
#include "event.h"

using namespace std;

class Bats : public Event
{
	private:

	public:
		Bats();
		~Bats();

		//getters
		string get_name();

		//setters


		//see if event is nearby
		void percept();
		//if player walks into the room
		void encounter();
};

#endif