#ifndef ESCAPE_ROPE_H
#define ESCAPE_ROPE_H

#include <iostream>
#include <cstdlib>
#include <vector>
#include "event.h"

using namespace std;

class Escape_rope : public Event
{
	private:

	public:
		Escape_rope();
		~Escape_rope();

		//getters
		string get_name();

		//setters


		//see if event is nearby
		void percept();
		//if player walks into the room
		void encounter();
};

#endif