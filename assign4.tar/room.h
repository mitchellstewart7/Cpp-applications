#ifndef ROOM_H
#define ROOM_H

#include <iostream>
#include <cstdlib>
#include <vector>
#include "event.h"
#include "bats.h"
#include "pit.h"
#include "wumpus.h"
#include "gold.h"
#include "escape_rope.h"

using namespace std;

class Room
{
private:
	string symbol;
	Event * event;
public:
	Room();
	~Room();
	void delete_room_memory();

	//getters
	string get_symbol();
	Event * get_event();

	//set event
	void set_event(string name);
	void set_symbol(string symbol);
	void remove_event();

};

#endif