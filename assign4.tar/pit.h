#ifndef PIT_H
#define PIT_H

#include <iostream>
#include <cstdlib>
#include <vector>
#include "event.h"

using namespace std;

class Pit : public Event
{
	private:

	public:
		Pit();
		~Pit();

		//getters
		string get_name();

		//setters


		//see if event is nearby
		void percept();
		//if player walks into the room
		void encounter();
};

#endif