#include <iostream>
#include <vector>
#include "event.h"
#include "pit.h"
#include "bats.h"
#include "gold.h"
#include "wumpus.h"
#include "room.h"
#include "escape_rope.h"

using namespace std;

/*********************************************************************
** Function: room
** Description: constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: room object
*********************************************************************/
Room::Room()
{
	//cout << "Room constructor called" << endl;
	this->symbol = " ";
	this->event = NULL;
}

/*********************************************************************
** Function: ~room
** Description: destructor
** Parameters: none
** Pre-Conditions: full board
** Post-Conditions: empty board
*********************************************************************/
Room::~Room()
{
	//cout << "room destructor called" << endl;
	//delete this->event;
	//this->event = NULL;
}

/*********************************************************************
** Function: delete_room_memory
** Description: deletes event from room
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted memory
*********************************************************************/
void Room::delete_room_memory()
{
	delete this->event;
	this->event = NULL;
}

/*********************************************************************
** Function: getters
** Description: returns value
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: value
*********************************************************************/
string Room::get_symbol()
{
	return this->symbol;
}

Event * Room::get_event()
{
	return this->event;
}

/*********************************************************************
** Function: setters
** Description: sets values
** Parameters: value
** Pre-Conditions: none
** Post-Conditions: set value
*********************************************************************/
void Room::set_symbol(string symbol)
{
	this->symbol = symbol;
}

void Room::set_event(string name)
{
	if (name == "wumpus")
	{
		this->event = new Wumpus;
	}
	else if (name == "pit")
	{
		this->event = new Pit;
	}
	else if (name == "bats")
	{
		this->event = new Bats;
	}
	else if (name == "gold")
	{
		this->event = new Gold;
	}
	else if (name == "escape_rope")
	{
		this->event = new Escape_rope;
	}
}

/*********************************************************************
** Function: remove_event
** Description: removes event from room
** Parameters: none
** Pre-Conditions: event in room
** Post-Conditions: empty room
*********************************************************************/
void Room::remove_event()
{
	if (this->event != NULL)
	{
		delete this->event;
		this->event = NULL;
	}
}



