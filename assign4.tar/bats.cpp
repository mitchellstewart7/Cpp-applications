#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>
#include "bats.h"
#include "event.h"

using namespace std;

/*********************************************************************
** Function: bats
** Description: constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new bats object
*********************************************************************/
Bats::Bats()
{
	this->name = "bats";
}

/*********************************************************************
** Function: ~bats
** Description: destructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted object
*********************************************************************/
Bats::~Bats()
{}

/*********************************************************************
** Function: get_name
** Description: gets the name
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: string
*********************************************************************/
string Bats::get_name()
{
	return "bats";
}

/*********************************************************************
** Function: percept
** Description: bats percept
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Bats::percept()
{
	cout << "you hear wings flapping" << endl;
}

/*********************************************************************
** Function: encounter
** Description: bats encounter
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Bats::encounter()
{
	cout << "You have been taken away by bats and moved to a random location" << endl;
}