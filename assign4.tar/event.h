#ifndef EVENT_H
#define EVENT_H

#include <iostream>
#include <cstdlib>
#include <vector>

using namespace std;

class Event 
{
	protected:
		string name;
	public:
		//getters
		virtual string get_name() = 0;
		//see if event is nearby
		virtual void percept() = 0;
		//if player walks into the room
		virtual void encounter() = 0;

};

#endif