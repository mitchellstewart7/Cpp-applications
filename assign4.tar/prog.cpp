#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <string>
#include <cstring>
#include <ctime>
#include "bats.h"
#include "pit.h"
#include "wumpus.h"
#include "gold.h"
#include "event.h"
#include "room.h"
#include "game.h"
#include "player.h"
#include "escape_rope.h"

using namespace std;

int main(int argc, char * argv[])
{
	Player * p = new Player;
	int answer;
	string mode = argv[2];
	if (argc == 3 && (mode == "true"))
	{
		if (atoi(argv[1]) >= 4)
		{
			srand(time(NULL));
			cout << "Debug Mode:" << endl;
			Game g(atoi(argv[1]));
			g.generate_random_board(p);
			g.print_cave();
			g.event_close(p);
			while (p->alive == true)
			{
				g.action(p);
				if (p->alive == false)
				{
					g.delete_cave_memory();
					cout << "Would you like to:" << endl;
					cout << "Play again with a random configuration (1)" << endl;
					cout << "Play again with same configuration (2)" << endl;
					cout << "Quit (3)" << endl;
					cin >> answer;
					if (answer == 1)
					{
						g.clear_board();
						g.generate_random_board(p);
						g.print_cave();
						g.event_close(p);
						p->num_arrows = 3;
						p->killed_wumpus = false;
						p->found_gold = false;
						p->alive = true;
					}
					else if (answer == 2)
					{
						g.clear_board();
						g.print_cave();
						g.event_close(p);
						g.run_same_board(p);
						p->num_arrows = 3;
						p->killed_wumpus = false;
						p->found_gold = false;
						p->alive = true;
					}
				}
			}
			g.delete_cave_memory();
			delete p; 
			return 1;
		}
		else
		{
			cout << "Please enter integer greater than or equal to 4 in command line" << endl;
			delete p;
			return 1;
		}
	}
	else if (argc == 3 && (mode == "false"))
	{
		if (atoi(argv[1]) >= 4)
		{
			srand(time(NULL));
			cout << "Normal Mode:" << endl;
			Game g(atoi(argv[1]));
			g.generate_random_board(p);
			g.print_hidden_cave(p);
			g.event_close(p);
			while (p->alive == true)
			{
				g.hidden_action(p);
				if (p->alive == false)
				{
					g.delete_cave_memory();
					cout << "Would you like to:" << endl;
					cout << "Play again with a random configuration (1)" << endl;
					cout << "Play again with same configuration (2)" << endl;
					cout << "Quit (3)" << endl;
					cin >> answer;
					if (answer == 1)
					{
						g.clear_board();
						g.generate_random_board(p);
						g.print_hidden_cave(p);
						g.event_close(p);
						p->num_arrows = 3;
						p->killed_wumpus = false;
						p->found_gold = false;
						p->alive = true;
					}
					else if (answer == 2)
					{
						g.clear_board();
						g.print_hidden_cave(p);
						g.event_close(p);
						g.run_same_board(p);
						p->num_arrows = 3;
						p->killed_wumpus = false;
						p->found_gold = false;
						p->alive = true;
					}
				}
			}
			g.delete_cave_memory();
			delete p;
			return 1;
		}
		else
		{
			cout << "Please enter integer greater than or equal to 4 in command line" << endl;
			delete p;
			return 1;
		}
	}
	else 
	{
		cout << "Please enter in command line your size and mode" << endl;
		delete p;
		return 1;
	}
}
