#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>

using namespace std;

struct Player
{
	bool alive = true;
	bool killed_wumpus = false;
	bool found_gold = false;
	int starting_x = 0;
	int starting_y = 0;
	int current_x = 0;
	int current_y = 0;
	int num_arrows = 3;
	int wumpus_start_x = 0;
	int wumpus_start_y = 0;
	int gold_start_x = 0;
	int gold_start_y = 0;
	int bats_start_x1 = 0;
	int bats_start_y1 = 0;
	int pit_start_x1 = 0;
	int pit_start_y1 = 0;
	int bats_start_x2 = 0;
	int bats_start_y2 = 0;
	int pit_start_x2 = 0;
	int pit_start_y2 = 0;
};

#endif