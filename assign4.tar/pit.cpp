#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>
#include "pit.h"
#include "event.h"

using namespace std;

/*********************************************************************
** Function: pit
** Description: constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new pit object
*********************************************************************/
Pit::Pit()
{
	this->name = "pit";
}

/*********************************************************************
** Function: ~pit
** Description: destructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted object
*********************************************************************/
Pit::~Pit()
{}

/*********************************************************************
** Function: get_name
** Description: gets the name
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: string
*********************************************************************/
string Pit::get_name()
{
	return "pit";
}

/*********************************************************************
** Function: percept
** Description: pit percept
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Pit::percept()
{
	cout << "You feel a breeze" << endl;
}

/*********************************************************************
** Function: encounter
** Description: pit encounter
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Pit::encounter()
{
	cout << "you have fallen into the bottomless pit and died" << endl;
}