#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>
#include "wumpus.h"
#include "event.h"

using namespace std;

/*********************************************************************
** Function: wumpus
** Description: constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new wumpus object
*********************************************************************/
Wumpus::Wumpus()
{
	this->name = "wumpus";
}

/*********************************************************************
** Function: ~wumpus
** Description: destructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted object
*********************************************************************/
Wumpus::~Wumpus()
{}

/*********************************************************************
** Function: get_name
** Description: gets the name
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: string
*********************************************************************/
string Wumpus::get_name()
{
	return "wumpus";
}

/*********************************************************************
** Function: percept
** Description: wumpus percept
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Wumpus::percept()
{
	cout << "You smell a terrible stench" << endl;
}

/*********************************************************************
** Function: encounter
** Description: wumpus encounter
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Wumpus::encounter()
{
	cout << "You have been eaten by the Wumpus" << endl;
}