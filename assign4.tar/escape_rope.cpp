#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>
#include "escape_rope.h"
#include "event.h"

using namespace std;

/*********************************************************************
** Function: escape_rope
** Description: constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new escape room object
*********************************************************************/
Escape_rope::Escape_rope()
{
	this->name = "escape_rope";
}

/*********************************************************************
** Function: ~escape_rope
** Description: destructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted object
*********************************************************************/
Escape_rope::~Escape_rope()
{}

/*********************************************************************
** Function: get_name
** Description: gets the name
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: string
*********************************************************************/
string Escape_rope::get_name()
{
	return "escape_rope";
}

/*********************************************************************
** Function: percept
** Description: escape rope percept
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Escape_rope::percept()
{

}

/*********************************************************************
** Function: encounter
** Description: escape room encounter
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed statement
*********************************************************************/
void Escape_rope::encounter()
{
	
}