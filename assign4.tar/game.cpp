#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <string>
#include "bats.h"
#include "pit.h"
#include "wumpus.h"
#include "gold.h"
#include "event.h"
#include "room.h"
#include "game.h"
#include "player.h"
#include "escape_rope.h"

using namespace std;

/*********************************************************************
** Function: Game()
** Description: Constructor
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new game object
*********************************************************************/
Game::Game()
{
	this->cave;
	this->size;
}

/*********************************************************************
** Function: Game(int)
** Description: Non-default constructor
** Parameters: int
** Pre-Conditions: none
** Post-Conditions: new game object of specified size
*********************************************************************/
Game::Game(int size)
{
	this->size = size;
	for (int i = 0; i < size; ++i)
	{
		vector<Room> row;
		for (int j = 0; j < size; ++j)
		{
			row.push_back(Room());
		}
		this->cave.push_back(row);
	}
}

/*********************************************************************
** Function: ~Game()
** Description: Destructor
** Parameters: none
** Pre-Conditions: existing game object
** Post-Conditions: deleted game object
*********************************************************************/
Game::~Game()
{}

/*********************************************************************
** Function: print_cave()
** Description: prints out the cave
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: printed out cave
*********************************************************************/
void Game::print_cave()
{
	for (int i = 0; i < this->size; ++i)
	{
		cout << "----";
	}
	cout << endl;
	for (int i = 0; i < this->size; ++i)
	{
		for (int j = 0; j < this->size; ++j)
		{
			if (j != this->size - 1)
				cout << " " << this->cave[i][j].get_symbol() << " " << "|";
			else
				cout << " " << this->cave[i][j].get_symbol() << " ";
		}
		cout << endl;
		for (int i = 0; i < this->size; ++i)
		{
			cout << "----";
		}
		cout << endl;
	}
}

/*********************************************************************
** Function: print_hidden_cave()
** Description: prints the cave, but hides symbols
** Parameters: Player pointer
** Pre-Conditions: none
** Post-Conditions: printed cave
*********************************************************************/
void Game::print_hidden_cave(Player * p)
{
	for (int i = 0; i < this->size; ++i)
	{
		cout << "----";
	}
	cout << endl;
	for (int i = 0; i < this->size; ++i)
	{
		for (int j = 0; j < this->size; ++j)
		{
			if (j != this->size - 1 && (this->cave[i][j].get_symbol() == "." || (this->cave[i][j].get_symbol() == "E" && i == p->current_x && j == p->current_y)))
			{
				cout << " " << "." << " " << "|";
			}
			else if (j != this->size - 1 && this->cave[i][j].get_symbol() != ".")
			{
				cout << "   |";
			}
			else
			{
				if (this->cave[i][j].get_symbol() == "." || (this->cave[i][j].get_symbol() == "E" && i == p->current_x && j == p->current_y))
				{
					cout << " " << "." << " ";
				}
				else
				{
					cout << "   ";
				}
			}
		}
		cout << endl;
		for (int i = 0; i < this->size; ++i)
		{
			cout << "----";
		}
		cout << endl;
	}
}

/*********************************************************************
** Function: empty_space()
** Description: checks to see if a room in cave doesn't have an event
** Parameters: two ints
** Pre-Conditions: none
** Post-Conditions: none
*********************************************************************/
bool Game::empty_space(int x, int y)
{
	if (this->cave[x][y].get_event() != NULL)
	{
		return false;
	}
	return true;
}

/*********************************************************************
** Function: generate_random_board()
** Description: generates a cave with random placementof events and the player
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created cave with symbols
*********************************************************************/
void Game::generate_random_board(Player * p)
{
	this->generate_random_wumpus(p);
	this->generate_random_gold(p);
	this->generate_random_bats(p);
	this->generate_random_pit(p);
	this->generate_random_player(p);
	this->generate_random_escape_rope(p);
}

/*********************************************************************
** Function: generate_random_escape_rope()
** Description: generates a random spot for the escape rope
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created event
*********************************************************************/
void Game::generate_random_escape_rope(Player * p)
{
	this->cave[p->starting_x][p->starting_y].set_event("escape_rope");
	this->cave[p->starting_x][p->starting_y].set_symbol("E");
}

/*********************************************************************
** Function: generate_random_wumpus()
** Description: generates a random spot for the wumpus
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created event
*********************************************************************/
void Game::generate_random_wumpus(Player * p)
{
	bool again = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (this->empty_space(x,y))
		{
			this->cave[x][y].set_event("wumpus");
			this->cave[x][y].set_symbol("W");
			again = false;
		}
		p->wumpus_start_x = x;
		p->wumpus_start_y = y;
	}
}

/*********************************************************************
** Function: generate_random_gold()
** Description: generates a random spot for the gold
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created event
*********************************************************************/
void Game::generate_random_gold(Player * p)
{
	bool again = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (this->empty_space(x,y))
		{
			this->cave[x][y].set_event("gold");
			this->cave[x][y].set_symbol("G");
			again = false;
		}
		p->gold_start_x = x;
		p->gold_start_y = y;
	}
}

/*********************************************************************
** Function: generate_random_bats()
** Description: generates a random spot for the bats
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created event
*********************************************************************/
void Game::generate_random_bats(Player * p)
{
	bool again = true;
	bool again2 = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (this->empty_space(x,y))
		{
			this->cave[x][y].set_event("bats");
			this->cave[x][y].set_symbol("B");
			again = false;
		}
		p->bats_start_x1 = x;
		p->bats_start_y1 = y;
	}
	while (again2)
	{
		int i = rand() % this->size;
		int j = rand() % this->size;
		if (this->empty_space(i,j))
		{
			this->cave[i][j].set_event("bats");
			this->cave[i][j].set_symbol("B");
			again2 = false;
		}
		p->bats_start_x2 = i;
		p->bats_start_y2 = j;
	}
}

/*********************************************************************
** Function: generate_random_pit()
** Description: generates a random spot for the pits
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created event
*********************************************************************/
void Game::generate_random_pit(Player * p)
{
	bool again = true;
	bool again2 = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (this->empty_space(x,y))
		{
			this->cave[x][y].set_event("pit");
			this->cave[x][y].set_symbol("P");
			again = false;
		}
		p->pit_start_x1 = x;
		p->pit_start_y1 = y;
	}
	while (again2)
	{
		int i = rand() % this->size;
		int j = rand() % this->size;
		if (this->empty_space(i,j))
		{
			this->cave[i][j].set_event("pit");
			this->cave[i][j].set_symbol("P");
			again2 = false;
		}
		p->pit_start_x2 = i;
		p->pit_start_y2 = j;
	}
}

/*********************************************************************
** Function: generate_random_player()
** Description: generates a random spot for the player
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: created player
*********************************************************************/
void Game::generate_random_player(Player * p)
{
	bool again = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (this->empty_space(x,y))
		{
			this->cave[x][y].set_symbol(".");
			p->starting_x = x;
			p->starting_y = y;
			p->current_x = x;
			p->current_y = y;
			again = false;
		}
	}
}

/*********************************************************************
** Function: delete_cave_memory()
** Description: deletes dynamic memory from cave's rooms
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: deleted memory
*********************************************************************/
void Game::delete_cave_memory()
{
	for (int i = 0; i < size; ++i)
	{
		for (int j = 0; j < size; ++j)
		{
			this->cave[i][j].delete_room_memory();
		}
	}
}

/*********************************************************************
** Function: event_close
** Description: detects if percept should be executed
** Parameters: Player object
** Pre-Conditions: player is one spot from event
** Post-Conditions: printed statement
*********************************************************************/
void Game::event_close(Player * p)
{
	this->event_close_middle(p);
	this->event_close_bottom(p);
	this->event_close_top(p);
	this->event_close_right(p);
	this->event_close_left(p);
}

/*********************************************************************
** Function: event_close_middle
** Description: detects if percept should be executed in middle of cave
** Parameters: Player object
** Pre-Conditions: player is one spot from event
** Post-Conditions: printed statement
*********************************************************************/
void Game::event_close_middle(Player * p)
{
	if (p->current_x < this->size - 1 && p->current_x > 0 && p->current_y < this->size - 1 && p->current_y > 0)
	{
		if (this->cave[p->current_x + 1][p->current_y].get_event() != NULL)
		{
			this->cave[p->current_x + 1][p->current_y].get_event()->percept();
		}
		if (this->cave[p->current_x - 1][p->current_y].get_event() != NULL)
		{
			this->cave[p->current_x - 1][p->current_y].get_event()->percept();
		}
		if (this->cave[p->current_x][p->current_y + 1].get_event() != NULL)
		{
			this->cave[p->current_x][p->current_y + 1].get_event()->percept();
		}
		if (this->cave[p->current_x][p->current_y - 1].get_event() != NULL)
		{
			this->cave[p->current_x][p->current_y - 1].get_event()->percept();
		}
	}
}

/*********************************************************************
** Function: event_close
** Description: detects if percept should be executed on bottom of cave
** Parameters: Player object
** Pre-Conditions: player is one spot from event
** Post-Conditions: printed statement
*********************************************************************/
void Game::event_close_bottom(Player * p)
{
	if (p->current_x == this->size - 1)
	{
		if (p->current_y == this->size - 1)
		{
			if (this->cave[p->current_x - 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x - 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y - 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y - 1].get_event()->percept();
			}
		}
		else if (p->current_y == 0)
		{
			if (this->cave[p->current_x - 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x - 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y + 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y + 1].get_event()->percept();
			}
		}
		else
		{
			if (this->cave[p->current_x - 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x - 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y + 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y + 1].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y - 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y - 1].get_event()->percept();
			}
		}
	}
}

/*********************************************************************
** Function: event_close
** Description: detects if percept should be executed on right of cave
** Parameters: Player object
** Pre-Conditions: player is one spot from event
** Post-Conditions: printed statement
*********************************************************************/
void Game::event_close_right(Player * p)
{
	if (p->current_y == this->size - 1)
	{
		if (p->current_x == 0)
		{
			if (this->cave[p->current_x + 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x + 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y - 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y - 1].get_event()->percept();
			}
		}
		else if (p->current_x < this->size - 1)
		{
			if (this->cave[p->current_x - 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x - 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y - 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y - 1].get_event()->percept();
			}
			if (this->cave[p->current_x + 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x + 1][p->current_y].get_event()->percept();
			}
		}
	}
}

/*********************************************************************
** Function: event_close
** Description: detects if percept should be executed on top of cave
** Parameters: Player object
** Pre-Conditions: player is one spot from event
** Post-Conditions: printed statement
*********************************************************************/
void Game::event_close_top(Player * p)
{
	if (p->current_x == 0)
	{
		if (p->current_y == 0)
		{
			if (this->cave[p->current_x + 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x + 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y + 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y + 1].get_event()->percept();
			}
		}
		else if (p->current_y < this-> size - 1)
		{
			if (this->cave[p->current_x + 1][p->current_y].get_event() != NULL)
			{
				this->cave[p->current_x + 1][p->current_y].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y + 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y + 1].get_event()->percept();
			}
			if (this->cave[p->current_x][p->current_y - 1].get_event() != NULL)
			{
				this->cave[p->current_x][p->current_y - 1].get_event()->percept();
			}
		}
	}
}

/*********************************************************************
** Function: event_close
** Description: detects if percept should be executed on left of cave
** Parameters: Player object
** Pre-Conditions: player is one spot from event
** Post-Conditions: printed statement
*********************************************************************/
void Game::event_close_left(Player * p)
{
	if (p->current_y == 0 && p->current_x > 0 && p->current_x < this->size - 1)
	{
		if (this->cave[p->current_x - 1][p->current_y].get_event() != NULL)
		{
			this->cave[p->current_x - 1][p->current_y].get_event()->percept();
		}
		if (this->cave[p->current_x + 1][p->current_y].get_event() != NULL)
		{
			this->cave[p->current_x + 1][p->current_y].get_event()->percept();
		}
		if (this->cave[p->current_x][p->current_y + 1].get_event() != NULL)
		{
			this->cave[p->current_x][p->current_y + 1].get_event()->percept();
		}
	}
}

/*********************************************************************
** Function: move
** Description: deals with player movement
** Parameters: Player object and string
** Pre-Conditions: none
** Post-Conditions: player moved
*********************************************************************/
void Game::move(string direction, Player * p)
{
	if (direction == "w")
	{
		this->move_up(p);
	}
	else if (direction == "a")
	{
		this->move_left(p);
	}
	else if (direction == "s")
	{
		this->move_down(p);
	}
	else if (direction == "d")
	{
		this->move_right(p);
	}
}

/*********************************************************************
** Function: move_up
** Description: deals with player movement
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player moved up
*********************************************************************/
void Game::move_up(Player * p)
{
	if (p->current_x > 0)
	{
		if (this->empty_space(p->current_x - 1, p->current_y))
		{
			if (cave[p->current_x][p->current_y].get_event() != NULL && cave[p->current_x][p->current_y].get_event()->get_name() == "escape_rope")
			{
				cave[p->current_x][p->current_y].set_symbol("E");
			}
			else
			{
				cave[p->current_x][p->current_y].set_symbol(" ");
			}
			cave[p->current_x - 1][p->current_y].set_symbol(".");
			p->current_x--;
		}
		else
		{
			cave[p->current_x][p->current_y].set_symbol(" ");
			p->current_x--;
			this->event_room(p);
		}
	}
}

/*********************************************************************
** Function: move_down
** Description: deals with player movement
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player moved down
*********************************************************************/
void Game::move_down(Player * p)
{
	if (p->current_x < this->size - 1)
	{
		if (this->empty_space(p->current_x + 1, p->current_y))
		{
			if (cave[p->current_x][p->current_y].get_event() != NULL && cave[p->current_x][p->current_y].get_event()->get_name() == "escape_rope")
			{
				cave[p->current_x][p->current_y].set_symbol("E");
			}
			else
			{
				cave[p->current_x][p->current_y].set_symbol(" ");
			}
			cave[p->current_x + 1][p->current_y].set_symbol(".");
			p->current_x++;
		}
		else
		{
			cave[p->current_x][p->current_y].set_symbol(" ");
			p->current_x++;
			this->event_room(p);
		}
	}
}

/*********************************************************************
** Function: move_right
** Description: deals with player movement
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player moved right
*********************************************************************/
void Game::move_right(Player * p)
{
	if (p->current_y < this->size - 1)
	{
		if (this->empty_space(p->current_x, p->current_y + 1))
		{
			if (cave[p->current_x][p->current_y].get_event() != NULL && cave[p->current_x][p->current_y].get_event()->get_name() == "escape_rope")
			{
				cave[p->current_x][p->current_y].set_symbol("E");
			}
			else
			{
				cave[p->current_x][p->current_y].set_symbol(" ");
			}
			cave[p->current_x][p->current_y + 1].set_symbol(".");
			p->current_y++;
		}
		else
		{
			cave[p->current_x][p->current_y].set_symbol(" ");
			p->current_y++;
			this->event_room(p);
		}
	}
}

/*********************************************************************
** Function: move_left
** Description: deals with player movement
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player moved left
*********************************************************************/
void Game::move_left(Player * p)
{
	if (p->current_y > 0)
	{
		if (this->empty_space(p->current_x, p->current_y - 1))
		{
			if (cave[p->current_x][p->current_y].get_event() != NULL && cave[p->current_x][p->current_y].get_event()->get_name() == "escape_rope")
			{
				cave[p->current_x][p->current_y].set_symbol("E");
			}
			else
			{
				cave[p->current_x][p->current_y].set_symbol(" ");
			}
			cave[p->current_x][p->current_y - 1].set_symbol(".");
			p->current_y--;
		}
		else 
		{
			cave[p->current_x][p->current_y].set_symbol(" ");
			p->current_y--;
			this->event_room(p);
		}
	}
}

/*********************************************************************
** Function: action
** Description: deals with player choice to shoot or move
** Parameters: Player object
** Pre-Conditions: user enters input
** Post-Conditions: player does action
*********************************************************************/
void Game::action(Player * p)
{
	string input;
	cout << "Enter an action:" << endl;
	cout << "Use wasd to move" << endl;
	cout << "To shoot an arrow, enter a space before entering the wasd in the desired direction" << endl;
	getline(cin, input);
	if (input.length() == 1)
		this->move(input, p);
	if (input.length() == 2)
		this->shoot(input, p);
	this->print_cave();
	if (p->alive == true)
		this->event_close(p);
}

/*********************************************************************
** Function: hidden_action
** Description: deals with player choice to shoot or move
** Parameters: Player object
** Pre-Conditions: user enters input
** Post-Conditions: player does action
*********************************************************************/
void Game::hidden_action(Player * p)
{
	string input;
	cout << "Enter an action:" << endl;
	cout << "Use wasd to move" << endl;
	cout << "To shoot an arrow, enter a space before entering the wasd in the desired direction" << endl;
	getline(cin, input);
	if (input.length() == 1)
		this->move(input, p);
	if (input.length() == 2)
		this->shoot(input, p);
	this->print_hidden_cave(p);
	if (p->alive == true)
		this->event_close(p);
}

/*********************************************************************
** Function: event_room
** Description: deals with player walking into event room
** Parameters: Player object
** Pre-Conditions: player is in event room
** Post-Conditions: player goes through event
*********************************************************************/
void Game::event_room(Player * p)
{
	if (cave[p->current_x][p->current_y].get_event() != NULL)
	{
		if (cave[p->current_x][p->current_y].get_event()->get_name() == "wumpus")
		{
			this->wumpus_event(p);
		}
		else if (cave[p->current_x][p->current_y].get_event()->get_name() == "bats")
		{
			this->bats_event(p);
		}
		else if (cave[p->current_x][p->current_y].get_event()->get_name() == "pit")
		{
			this->pit_event(p);
		}
		else if (cave[p->current_x][p->current_y].get_event()->get_name() == "gold")
		{
			this->gold_event(p);
		}
		else if (cave[p->current_x][p->current_y].get_event()->get_name() == "escape_rope")
		{
			this->escape_event(p);
		}
	}
}

/*********************************************************************
** Function: wumpus_event
** Description: deals with player walking into wumpus room
** Parameters: Player object
** Pre-Conditions: player is in event room
** Post-Conditions: player goes through event
*********************************************************************/
void Game::wumpus_event(Player * p)
{
	cave[p->current_x][p->current_y].get_event()->encounter();
	p->alive = false;
}

/*********************************************************************
** Function: bats_event
** Description: deals with player walking into bats room
** Parameters: Player object
** Pre-Conditions: player is in event room
** Post-Conditions: player goes through event
*********************************************************************/
void Game::bats_event(Player * p)
{
	cave[p->current_x][p->current_y].get_event()->encounter();
	cave[p->current_x][p->current_y].set_symbol("B");
	bool again = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (!(x == p->current_x && y == p->current_y))
		{
			if (this->empty_space(x,y))
			{
				this->cave[x][y].set_symbol(".");
				p->current_x = x;
				p->current_y = y;
				again = false;
			}
			else 
			{
				p->current_x = x;
				p->current_y = y;
				event_room(p);
				again = false;
			}
		}
	}
}

/*********************************************************************
** Function: pit_event
** Description: deals with player walking into pit room
** Parameters: Player object
** Pre-Conditions: player is in event room
** Post-Conditions: player goes through event
*********************************************************************/
void Game::pit_event(Player * p)
{
	cave[p->current_x][p->current_y].get_event()->encounter();
	p->alive = false;
}

/*********************************************************************
** Function: gold_event
** Description: deals with player walking into gold room
** Parameters: Player object
** Pre-Conditions: player is in event room
** Post-Conditions: player goes through event
*********************************************************************/
void Game::gold_event(Player * p)
{
	cave[p->current_x][p->current_y].get_event()->encounter();
	cave[p->current_x][p->current_y].set_symbol(".");
	cave[p->current_x][p->current_y].remove_event();
	p->found_gold = true;
}

/*********************************************************************
** Function: escape_event
** Description: deals with player walking into escape room
** Parameters: Player object
** Pre-Conditions: player is in event room
** Post-Conditions: player goes through event
*********************************************************************/
void Game::escape_event(Player * p)
{
	if (p->killed_wumpus == true && p->found_gold == true)
	{
		cout << "YOU FOUND THE GOLD AND KILLED THE WUMPUS, YOU HAVE WON!!!" << endl;
		p->alive = false;
	}
}

/*********************************************************************
** Function: wumpus_dead
** Description: deals with player killing wumpus
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: wumpus dies
*********************************************************************/
bool Game::wumpus_dead(Player * p)
{
	if (p->killed_wumpus == true)
	{
		return true;
	}
	return false;
}

/*********************************************************************
** Function: wumpus_move
** Description: deals with wumpus moving
** Parameters: none
** Pre-Conditions: players arrow misses
** Post-Conditions: wumpus moves
*********************************************************************/
void Game::wumpus_move()
{
	for (int i = 0; i < this->size; ++i)
	{
		for (int j = 0; j < this->size; ++j)
		{
			if (cave[i][j].get_event() != NULL)
			{
				if (cave[i][j].get_event()->get_name() == "wumpus")
				{
					cout << "The arrow woke up the Wumpus, and it moved" << endl;
					cave[i][j].set_symbol(" ");
					cave[i][j].remove_event();
				}
			}
		}
	}
	bool again = true;
	while (again)
	{
		int x = rand() % this->size;
		int y = rand() % this->size;
		if (this->empty_space(x,y))
		{
			if (cave[x][y].get_symbol() != ".")
			{
				this->cave[x][y].set_event("wumpus");
				this->cave[x][y].set_symbol("W");
				again = false;
			}
		}
	}
}

/*********************************************************************
** Function: shoot
** Description: player shoots
** Parameters: Player object and string
** Pre-Conditions: none
** Post-Conditions: player shoots in given direction
*********************************************************************/
void Game::shoot(string direction, Player * p)
{
	if (direction == " w")
	{
		this->shoot_up(p);
	}
	else if (direction == " a")
	{
		this->shoot_left(p);
	}
	else if (direction == " s")
	{
		this->shoot_down(p);
	}
	else if (direction == " d")
	{
		this->shoot_right(p);
	}
	if (!this->wumpus_dead(p))
	{
		p->num_arrows--;
		cout << "Arrow missed the wumpus, you now have " << p->num_arrows << " left" << endl;
		int wumpus_wake = rand() % 4;
		if (wumpus_wake < 3)
			this->wumpus_move();
	}
	if (p->num_arrows == 0)
	{
		cout << "You ran out of arrows, you are dead" << endl;
		p->alive = false;
	}
}

/*********************************************************************
** Function: shoot_up
** Description: player shoots up
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player shoots in given direction
*********************************************************************/
void Game::shoot_up(Player * p)
{
	if (p->current_x > 2)
	{
		for (int i = p->current_x - 3; i < p->current_x; ++i)
		{
			if (cave[i][p->current_y].get_event() != NULL)
			{
				if (cave[i][p->current_y].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[i][p->current_y].set_symbol(" ");
					cave[i][p->current_y].remove_event();
					p->killed_wumpus = true;
				}
			}
		} 
	}
	else
	{
		for (int i = 0; i < p->current_x; ++i)
		{
			if (cave[i][p->current_y].get_event() != NULL)
			{
				if (cave[i][p->current_y].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[i][p->current_y].set_symbol(" ");
					cave[i][p->current_y].remove_event();
					p->killed_wumpus = true;
				}
			}
		}
	}
}

/*********************************************************************
** Function: shoot_down
** Description: player shoots down
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player shoots in given direction
*********************************************************************/
void Game::shoot_down(Player * p)
{
	if (p->current_x < this->size - 3)
	{
		for (int i = p->current_x + 1; i < p->current_x + 4; ++i)
		{
			if (cave[i][p->current_y].get_event() != NULL)
			{
				if (cave[i][p->current_y].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[i][p->current_y].set_symbol(" ");
					cave[i][p->current_y].remove_event();
					p->killed_wumpus = true;
				}
			}
		} 
	}
	else
	{
		for (int i = p->current_x + 1; i < this->size; ++i)
		{
			if (cave[i][p->current_y].get_event() != NULL)
			{
				if (cave[i][p->current_y].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[i][p->current_y].set_symbol(" ");
					cave[i][p->current_y].remove_event();
					p->killed_wumpus = true;
				}
			}
		}
	}
}

/*********************************************************************
** Function: shoot_right
** Description: player shoots right
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player shoots in given direction
*********************************************************************/
void Game::shoot_right(Player * p)
{
	if (p->current_y < this->size - 3)
	{
		for (int i = p->current_y + 1; i < p->current_y + 4; ++i)
		{
			if (cave[p->current_x][i].get_event() != NULL)
			{
				if (cave[p->current_x][i].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[p->current_x][i].set_symbol(" ");
					cave[p->current_x][i].remove_event();
					p->killed_wumpus = true;
				}
			}
		} 
	}
	else
	{
		for (int i = p->current_y + 1; i < this->size; ++i)
		{
			if (cave[p->current_x][i].get_event() != NULL)
			{
				if (cave[p->current_x][i].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[p->current_x][i].set_symbol(" ");
					cave[p->current_x][i].remove_event();
					p->killed_wumpus = true;
				}
			}
		}
	}
}

/*********************************************************************
** Function: shoot_left
** Description: player shoots left
** Parameters: Player object
** Pre-Conditions: none
** Post-Conditions: player shoots in given direction
*********************************************************************/
void Game::shoot_left(Player * p)
{
	if (p->current_y > 2)
	{
		for (int i = p->current_y - 3; i < p->current_y; ++i)
		{
			if (cave[p->current_x][i].get_event() != NULL)
			{
				if (cave[p->current_x][i].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[p->current_x][i].set_symbol(" ");
					cave[p->current_x][i].remove_event();
					p->killed_wumpus = true;
				}
			}
		} 
	}
	else
	{
		for (int i = 0; i < p->current_y; ++i)
		{
			if (cave[p->current_x][i].get_event() != NULL)
			{
				if (cave[p->current_x][i].get_event()->get_name() == "wumpus")
				{
					cout << "You have killed the Wumpus" << endl;
					cave[p->current_x][i].set_symbol(" ");
					cave[p->current_x][i].remove_event();
					p->killed_wumpus = true;
				}
			}
		}
	}
}

/*********************************************************************
** Function: clear_board
** Description: wipes board of symbols and events
** Parameters: none
** Pre-Conditions: full board
** Post-Conditions: empty board
*********************************************************************/
void Game::clear_board()
{
	for (int i = 0; i < this->size; ++i)
	{
		for (int j = 0; j < this->size; ++j)
		{
			if (cave[i][j].get_event() != NULL)
			{
				cave[i][j].remove_event();
			}
		}
	}
	for (int i = 0; i < this->size; ++i)
	{
		for (int j = 0; j < this->size; ++j)
		{
			cave[i][j].set_symbol(" ");
		}
	}
}

/*********************************************************************
** Function: run_same_board
** Description: runs game with previous positions of events
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: new game w same events
*********************************************************************/
void Game::run_same_board(Player * p)
{
	cave[p->wumpus_start_x][p->wumpus_start_y].set_event("wumpus");
	cave[p->wumpus_start_x][p->wumpus_start_y].set_symbol("W");
	cave[p->gold_start_x][p->gold_start_y].set_event("gold");
	cave[p->gold_start_x][p->gold_start_y].set_symbol("G");
	cave[p->pit_start_x1][p->pit_start_y1].set_event("pit");
	cave[p->pit_start_x1][p->pit_start_y1].set_symbol("P");
	cave[p->pit_start_x2][p->pit_start_y2].set_event("pit");
	cave[p->pit_start_x2][p->pit_start_y2].set_symbol("P");
	cave[p->bats_start_x1][p->bats_start_y1].set_event("bats");
	cave[p->bats_start_x1][p->bats_start_y1].set_symbol("B");
	cave[p->bats_start_x2][p->bats_start_y2].set_event("bats");
	cave[p->bats_start_x2][p->bats_start_y2].set_symbol("B");
	p->current_x = p->starting_x;
	p->current_y = p->starting_y;
	cave[p->current_x][p->current_y].set_symbol(".");
	this->generate_random_escape_rope(p);
}