#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <string>
#include "bats.h"
#include "pit.h"
#include "wumpus.h"
#include "gold.h"
#include "event.h"
#include "room.h"
#include "player.h"

using namespace std;

class Game
{
private:
	vector<vector<Room> > cave;
	int size;
public:
	Game();
	Game(int size);
	~Game();

	//print cave functions
	void print_cave();
	void print_hidden_cave(Player * p);

	//randomly place events on the board
	bool empty_space(int x, int y);
	void generate_random_wumpus(Player * p);
	void generate_random_gold(Player * p);
	void generate_random_pit(Player * p);
	void generate_random_bats(Player * p);
	void generate_random_escape_rope(Player * p);
	void generate_random_player(Player * p);
	void generate_random_board(Player * p);

	//same setup as the first run through
	void run_same_board(Player * p);

	//move functions
	void move(string direction, Player * p);
	void move_up(Player * p);
	void move_down(Player * p);
	void move_right(Player * p);
	void move_left(Player * p);
	void action(Player * p);
	void hidden_action(Player * p);

	//shoot functions
	void shoot(string direction, Player * p);
	void shoot_up(Player * p);
	void shoot_down(Player * p);
	void shoot_right(Player * p);
	void shoot_left(Player * p);
	bool wumpus_dead(Player * p);
	void wumpus_move();

	//make percepts work
	void event_close(Player * p);
	void event_close_middle(Player * p);
	void event_close_right(Player * p);
	void event_close_left(Player * p);
	void event_close_bottom(Player * p);
	void event_close_top(Player * p);

	//make encounters work
	void event_room(Player * p);
	void wumpus_event(Player * p);
	void pit_event(Player * p);
	void bats_event(Player * p);
	void gold_event(Player * p);
	void escape_event(Player * p);

	//clear board
	void clear_board();

	//free memory
	void delete_cave_memory();



};

#endif