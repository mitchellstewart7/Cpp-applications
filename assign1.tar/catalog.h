#include <iostream> 
#include <cstdlib>
#include <fstream> 

using namespace std;

//struct for a wizard
struct wizard 
{
   string name;
   int id;
   string password;
   string position_title;
   float beard_length;
};

//struct for a spell
struct spell 
{
   string name;
   float success_rate;
   string effect;
};

//struct for a spellbook
struct spellbook
{
   string title;
   string author;
   int num_pages;
   int edition;
   int num_spells;
   float avg_success_rate;
   spell * s;
};

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: creates array of wizards of given size
** Input: an int variable
** Output: an array of wizards with empty characteristics
******************************************************/
wizard * create_wizards(int size);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: gives characteristics to every wizard that was created by create_wizards, and does this through reading the file wizards.txt
** Input: an array of wizards, an int for the number of wizards, and a reference to a filestream
** Output: nothing, but should give everything its characteristics
******************************************************/
void populate_wizard_data(wizard * w, int num_wizards, ifstream & fin);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: handles login of the user to a wizard profile, checks to make sure ID and password are correct. Loops through wizards.txt and reads it to check ID and password.\
** Input: a wizard array, a reference to a wizard, and an int for the number of wizards
** Output: a boolean representing whether the user logged in or not.\
******************************************************/
bool login(wizard * w, wizard & wiz, int num_wizards);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: creates an array of spellbook of the given size (size is read in from spellbooks.txt)
** Input: an int for size.\
** Output: an array of spellbooks
******************************************************/
spellbook * create_spellbooks(int size);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: Loops through spellbooks.txt to assign characteristics to every spellbook in the spellbook array, as well as its attached spell array
** Input: a spellbook array, the number of spellbooks, and a filestream reference
** Output: nothing, just everything in the array should have its characteristics
******************************************************/
void populate_spellbook_data(spellbook * sb, int num_spellbooks, ifstream & fin);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: creates an array of spells of specified length, done through looping through the spellbook array
** Input: an int for the size
** Output: an array of spells
******************************************************/
spell * create_spells(int size);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: assigns each spell in the spell array its characteristics, does this through looping through the spellbook array in populate_spellbook_data
** Input: an array of spells, an int for the number of spells, and a filestream reference
** Output: nothing, but everything should have its characteristics
******************************************************/
void populate_spell_data(spell * s, int num_spells, ifstream & fin);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: clears memory allocated on the heap
** Input: wizard double pointer, the number of wizards, a spellbook double pointer, the number of spellbooks
** Output: nothing, clears memory only
******************************************************/
void delete_info(wizard ** w, int num_wizards, spellbook ** sb, int num_spellbooks);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: sorts the spellbook array by the number of pages in each spellbook, in ascending order
** Input: a spellbook array and the number of spellbooks in it
** Output: a sorted array
******************************************************/
void sort_num_pages(spellbook * sb, int num_spellbooks);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: sorts and prints spell by effect they have
** Input: a spellbook array, the number of spellbooks in it, and the wizard who is viewing it
** Output: a sorted and printed list of spells in order of their effect, starting with bubble
******************************************************/
void sort_print_spells_effect(spellbook * sb, int num_spellbooks, wizard wiz);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: sorts a spellbook array by the average success rate of its spells
** Input: a spellbook array and the number of spellbooks in it
** Output: a sorted array
******************************************************/
void sort_avg_success(spellbook * sb, int num_spellbooks);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: checks to make sure that a spellbook does not have any spells with the effect of poison or death in them 
** Input: a spellbook
** Output: a boolean representing whether or not the spellbook is safe for a student
******************************************************/
bool check_safety(spellbook sb);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: prints the spellbook array to the screen, but only prints the spellbook name and the number of pages
** Input: a spellbook array in order, the number of spellbooks in it, and a wizard who is viewing it
** Output: the printed list of spellbooks in order from least pages to most, only with their names and number of pages listed
******************************************************/
void print_spellbook_pages_screen(spellbook * sb, int num_spellbooks, wizard wiz);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: prints the spellbook's name and average success rate
** Input: an ordered spellbook array, the number of spellbooks in it, and the wizard who is trying to view the information
** Output: prints the spellbook's name and average success rate to the screen
******************************************************/
void print_spellbook_avg_success(spellbook * sb, int num_spellbooks, wizard wiz);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: writes the spellbook name and number of pages to a file of the user's choice
** Input: a spellbook array, the number of spellbooks in it, a filestream reference, and the wizard who is trying to view the information
** Output: information is written to the specified file
******************************************************/
void print_spellbook_pages_file(spellbook * sb, int num_spellbooks, ofstream & fout, wizard wiz);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: writes the spellbook name and average success rate to a file of the user's choice
** Input: a spellbook array, the number of spellbooks in it, a filestream reference, adn the wizard trying to view the infromation
** Output: writes information to the specified file
******************************************************/
void print_spellbook_avg_file(spellbook * sb, int num_spellbooks, ofstream & fout, wizard wiz);

/******************************************************
** Program: catalog.h
** Author: Mitchell Stewart
** Date: 04/12/2020
** Description: writes list of spells to a desired file, creates new file if file doesn't exist 
** Input: spellbook array, the number of spellbooks in it, a filestream reference, and the wizard trying to view the information
** Output: writes spell effect and name to the specified file
******************************************************/
void print_spell_file(spellbook * sb, int num_spellbooks, ofstream & fout, wizard wiz);

