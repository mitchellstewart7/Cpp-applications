#include <iostream>
#include <fstream>
#include "catalog.h"

using namespace std;

/* this function is over 15 lines long because there is so much that goes into it. All of the functions I created must be used here,
 * as well as countless cout statements and looping for error handling */
int main(int argc, char * argv[])
{
   ifstream fin;
   ifstream fin2;
   fin.open(argv[1]);
   fin2.open(argv[2]);
   if (argc != 3 || !fin.is_open() || !fin2.is_open())
   {
      cout << "Error: Number of files are not 2 or files do not exist" << endl;
      return 1;
   }
   
   //variable declarations
   int num_wizards;
   int num_spellbooks;
   int num_spells;
   int answer;
   bool again = true;
   bool logged_in;
   wizard wiz;

   fin >> num_wizards;

   fin2 >> num_spellbooks;

   //setting up login and arrays of spellbooks and wizards
   wizard * w = create_wizards(num_wizards);

   populate_wizard_data(w, num_wizards, fin);

   logged_in = login(w, wiz, num_wizards);

   if (!logged_in)
   {
      return 1;
   }

   spellbook * sb = create_spellbooks(num_spellbooks);

   populate_spellbook_data(sb, num_spellbooks, fin2);

   cout << endl;

   while (again) //to let user sort again if they'd like
   {
      cout << "Which option would you like to choose?" << endl;
      cout << "1) Sort spellbooks by number of pages" << endl;
      cout << "2) Group spells by their effect" << endl;
      cout << "3) Sort spellbooks by their average success rate" << endl;
      cout << "4) Quit" << endl;
      cin >> answer;

      if (answer == 1){ //if user wants to sort by number of pages
	 bool again = true;
	 int answer;
	 while (again){
	    cout << "Would you like to" << endl;
	    cout << "1) Display information to the screen" << endl;
	    cout << "2) Write information to a file" << endl;
	    cin >> answer;
	    if (answer == 1){
               sort_num_pages(sb, num_spellbooks);
	       print_spellbook_pages_screen(sb, num_spellbooks, wiz);
	       again = false;
	    }
	    else if (answer == 2){
	       string file_name;
	       cout << "What filename would you like to write to?" << endl;
	       cin >> file_name;
	       ofstream fout;
	       fout.open(file_name.c_str(), ios::app);
	       sort_num_pages(sb, num_spellbooks);
	       print_spellbook_pages_file(sb, num_spellbooks, fout, wiz);
	       again = false; 
	       fout.close();
	    }
	    else {
	       cout << "Invalid entry, try again" << endl;
	    }
	 }
      }      
      else if (answer == 2){ //if user wants to sort by spell effect
      	 bool again = true;
	 int answer;
	 while (again){
	    cout << "Would you like to" << endl;
	    cout << "1) Display information to the screen" << endl;
	    cout << "2) Write information to a file" << endl;
	    cin >> answer;
	    if (answer == 1){
               sort_print_spells_effect(sb, num_spellbooks, wiz);
	       again = false;
	    }
	    else if (answer == 2){
	       string file_name;
	       cout << "What filename would you like to write to?" << endl;
	       cin >> file_name;
	       ofstream fout;
	       fout.open(file_name.c_str(), ios::app);
	       print_spell_file(sb, num_spellbooks, fout, wiz);
	       again = false; 
	       fout.close();
	    }
	    else {
	       cout << "Invalid entry, try again" << endl;
	    }
	 }
      }
      else if (answer == 3){ //if user wants to sort by average success rate of spellbooks
      	 bool again = true;
	 int answer;
	 while (again){
	    cout << "Would you like to" << endl;
	    cout << "1) Display information to the screen" << endl;
	    cout << "2) Write information to a file" << endl;
	    cin >> answer;
	    if (answer == 1){
               sort_avg_success(sb, num_spellbooks);
	       print_spellbook_avg_success(sb, num_spellbooks, wiz);
	       again = false;
	    }
	    else if (answer == 2){
	       string file_name;
	       cout << "What filename would you like to write to?" << endl;
	       cin >> file_name;
	       ofstream fout;
	       fout.open(file_name.c_str(), ios::app);
	       sort_avg_success(sb, num_spellbooks);
	       print_spellbook_avg_file(sb, num_spellbooks, fout, wiz);
	       again = false;
	       fout.close();
	    }
	    else {
	       cout << "Invalid entry, try again" << endl;
	    }
	 }
      }
      else if (answer == 4){ //if user wants to quit
	 again = false;
      }
      else { //error handling
	 cout << "Please enter a valid input and try again" << endl;
	 cout << endl;
      }
   }
   fin.close();
   fin2.close();

   delete_info(&w, num_wizards, &sb, num_spellbooks); //deleting created memory 
}
