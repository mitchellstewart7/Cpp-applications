#include <iostream>
#include <cstdlib>
#include <fstream>
#include "catalog.h"

using namespace std;

wizard * create_wizards(int size)
{
   wizard * w = new wizard[size];
   return w;
}

void populate_wizard_data(wizard * w, int num_wizards, ifstream & fin)
{
   for (int i = 0; i < num_wizards; i++)
   {
      fin >> w[i].name >> w[i].id >> w[i].password >> w[i].position_title >> w[i].beard_length;
   }
}

/* function is longer than 15 lines because of many cout statements and cin statements, as well as a while loop
 * which was necessary for error handling */
bool login(wizard * w, wizard & wiz,  int num_wizards)
{
   int id = 0;
   string password = "";
   int num_tries = 0;
   bool logged_in = false;

   while (num_tries < 3 && logged_in == false)
   {
      cout << "Please enter an ID:" << endl;
      cin >> id;
      while (cin.fail())
      {
	 cin.clear();
	 cin.ignore(256, '\n'); //ignores previous cin statement so new one can be made
	 cout << "Please enter an ID that is only integers" << endl;
	 cin >> id;
      }
      cout << "Please enter a password:" << endl;
      cin >> password;
      for (int i = 0; i < num_wizards; i++)
      {
	 if (id == w[i].id && password == w[i].password)
	 {
	    wiz = w[i];
	    logged_in = true;
	 }
      }
      if (!logged_in)
      {
	 cout << "Invalid ID or password" << endl;
	 num_tries++;
      }
   }
   if (logged_in)
   {
      cout << "Welcome " << wiz.name << endl;
      cout << "ID: " << wiz.id << endl;
      cout << "Status: " << wiz.position_title << endl;
      cout << "Beard Length: " << wiz.beard_length << endl;
      return logged_in; 
   }
   else 
   {
      return logged_in;
   }
}

spellbook * create_spellbooks(int size)
{
   spellbook * sb = new spellbook[size];
   return sb;
}

void populate_spellbook_data(spellbook * sb, int num_spellbooks, ifstream & fin)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      int total_success_rate = 0;
      fin >> sb[i].title >> sb[i].author >> sb[i].num_pages >> sb[i].edition >> sb[i].num_spells;
      sb[i].s = create_spells(sb[i].num_spells);
      populate_spell_data(sb[i].s, sb[i].num_spells, fin);
      for (int j = 0; j < sb[i].num_spells; j++)
      {
         total_success_rate += sb[i].s[j].success_rate;
      }
      sb[i].avg_success_rate = (float)total_success_rate / (float)sb[i].num_spells;
   }
}

spell * create_spells(int size)
{
   spell * s = new spell[size];
   return s;
}

void populate_spell_data(spell * s, int num_spells, ifstream & fin)
{
   for (int i = 0; i < num_spells; i++)
   {
      fin >> s[i].name >> s[i].success_rate >> s[i].effect;
   } 
}

bool check_safety(spellbook sb)
{
   for (int i = 0; i < sb.num_spells; i++)
   {
      if (sb.s[i].effect == "death" || sb.s[i].effect == "poison")
      {
	 return false;
      }
   }
   return true;
}

void sort_num_pages(spellbook * sb, int num_spellbooks)
{
   spellbook temp;
   for (int i = 0; i < num_spellbooks - 1; i++)
   {
      for (int j = 0; j < num_spellbooks - i - 1; j++)
      {
	 if (sb[j].num_pages > sb[j + 1].num_pages)
	 {
	    temp = sb[j];
	    sb[j] = sb[j + 1];
	    sb[j + 1] = temp;
	 }
      }
   }
}

/* function is longer than 15 lines because it requires so much looping. This would also be very hard 
 * to break down into smaller pieces */
void sort_print_spells_effect(spellbook * sb, int num_spellbooks, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int j = 0; j < sb[i].num_spells; j++)
      {
	 if (sb[i].s[j].effect == "bubble")
	    cout << sb[i].s[j].effect << " " << sb[i].s[j].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int k = 0; k < sb[i].num_spells; k++)
      {
	 if (sb[i].s[k].effect == "memory_loss")
	    cout << sb[i].s[k].effect << " " << sb[i].s[k].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int g = 0; g < sb[i].num_spells; g++)
      {
	 if (sb[i].s[g].effect == "fire")
	    cout << sb[i].s[g].effect << " " << sb[i].s[g].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int f = 0; f < sb[i].num_spells; f++)
      {
	 if (sb[i].s[f].effect == "poison" && wiz.position_title != "Student")
	    cout << sb[i].s[f].effect << " " << sb[i].s[f].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int h = 0; h < sb[i].num_spells; h++)
      {
	 if (sb[i].s[h].effect == "death" && wiz.position_title != "Student")
	    cout << sb[i].s[h].effect << " " << sb[i].s[h].name << endl;
      } 
   }
}

void sort_avg_success(spellbook * sb, int num_spellbooks)
{
   spellbook temp;
   for (int i = 0; i < num_spellbooks - 1; i++)
   {
      for (int j = 0; j < num_spellbooks - i - 1; j++)
      {
	 if (sb[j].avg_success_rate < sb[j + 1].avg_success_rate)
	 {
	    temp = sb[j];
	    sb[j] = sb[j + 1];
	    sb[j + 1] = temp;
	 }
      }
   }
}

void print_spellbook_pages_screen(spellbook * sb, int num_spellbooks, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      if (check_safety(sb[i]) || wiz.position_title != "Student")
      {
         cout << sb[i].title << " " << sb[i].num_pages << endl;
      }
   }
}

void print_spell_screen(spellbook * sb, int num_spellbooks, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int j = 0; j < sb[i].num_spells; j++)
      {
	 if ((sb[i].s[j].effect != "poison" && sb[i].s[j].effect != "death") || wiz.position_title != "Student")
	 {
	    cout << sb[i].s[j].effect << " " << sb[i].s[j].name << endl;
	 } 
      }
   }
}

void print_spellbook_pages_file(spellbook * sb, int num_spellbooks, ofstream & fout, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      if (check_safety(sb[i]) || wiz.position_title != "Student")
      {
         fout << sb[i].title << " " << sb[i].num_pages << endl;
      }
   }
}

void print_spellbook_avg_file(spellbook * sb, int num_spellbooks, ofstream & fout, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      if (check_safety(sb[i]) || wiz.position_title != "Student")
      {
         fout << sb[i].title << " " << sb[i].num_pages << endl;
      }
   }
}

/* similar to the related function a bit earlier, this requires large amounts of looping thus is over 15 lines */
void print_spell_file(spellbook * sb, int num_spellbooks, ofstream & fout, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int j = 0; j < sb[i].num_spells; j++)
      {
	 if (sb[i].s[j].effect == "bubble")
	    fout << sb[i].s[j].effect << " " << sb[i].s[j].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int k = 0; k < sb[i].num_spells; k++)
      {
	 if (sb[i].s[k].effect == "memory_loss")
	    fout << sb[i].s[k].effect << " " << sb[i].s[k].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int g = 0; g < sb[i].num_spells; g++)
      {
	 if (sb[i].s[g].effect == "fire")
	    fout << sb[i].s[g].effect << " " << sb[i].s[g].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int f = 0; f < sb[i].num_spells; f++)
      {
	 if (sb[i].s[f].effect == "poison" && wiz.position_title != "Student")
	    fout << sb[i].s[f].effect << " " << sb[i].s[f].name << endl;
      }
   }
   for (int i = 0; i < num_spellbooks; i++)
   {
      for (int h = 0; h < sb[i].num_spells; h++)
      {
	 if (sb[i].s[h].effect == "death" && wiz.position_title != "Student")
	    fout << sb[i].s[h].effect << " " << sb[i].s[h].name << endl;
      } 
   }
}

void print_spellbook_avg_success(spellbook * sb, int num_spellbooks, wizard wiz)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      if (check_safety(sb[i]) || wiz.position_title != "Student")
      {
         cout << sb[i].title << " " << sb[i].avg_success_rate << endl;    
      }
   }
}

void delete_info(wizard ** w, int num_wizards, spellbook ** spellbooks, int num_spellbooks)
{
   for (int i = 0; i < num_spellbooks; i++)
   {
      delete [] (*spellbooks)[i].s;
   }
   delete [] (*spellbooks);
   *spellbooks = NULL;
   delete [] (*w);
   *w = NULL;
}
